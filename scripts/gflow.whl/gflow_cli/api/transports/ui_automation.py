"""D.2.4 UiAutomationTransport — Playwright persistent-context driver for Flow.

Empirically validated 2026-05-12: mirrors the proven CG Worker pattern
(``scripts/smoke_worker_style.py``). Playwright manages its own internal CDP
port, the strategy reuses a pre-authenticated profile dir, and prompts are
submitted by typing into Flow's editor — the same surface a human developer
uses on a Pro/Ultra plan. ``batchGenerateImages`` responses are captured via
``page.on("response")`` and parsed for image URLs.

Implementation arrives in per-method TDD units; this skeleton pins the
Protocol contract.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import random
import re
import secrets
import time
from typing import TYPE_CHECKING, Any, ClassVar, cast
from urllib.parse import urlparse

import structlog

from gflow_cli.api._retry import parse_retry_after
from gflow_cli.api.character import CharacterImageRequest
from gflow_cli.api.dto import BatchSubmissionResult, GeneratedImage
from gflow_cli.api.image import Aspect, GenerateImageRequest, ImageRef, Model
from gflow_cli.api.transports._common import (
    await_url_settled,
    close_menu,
    count_visible,
    extract_project_id,
    flow_host_kind,
    generation_error,
    migrated_route,
    offered_menu_labels,
    raise_if_known_landing,
    raise_if_migrated,
)
from gflow_cli.api.transports.migrated_composer import (
    MENU_ITEM,
    ModelMenuMatcher,
    migrated_images_prefer,
)
from gflow_cli.api.transports.ui_automation_video import (
    ENTITY_ATTACH_DRIFT_HINT,
    MODE_SWITCH_TRIGGER_SELECTORS,
    VideoGenerationMixin,
    screenshot_clause,
    selector_drift_detail,
    zip_entity_refs,
)
from gflow_cli.errors import (
    AuthExpiredError,
    BatchPartialError,
    ConfigurationError,
    ContentPolicyError,
    FlowAppError,
    GFlowError,
    MentionIndexUnavailableError,
    RateLimitError,
    UiSelectorDriftError,
    WafRejectionError,
    WireFormatError,
)
from gflow_cli.profile_lease import ProfileLease

if TYPE_CHECKING:
    from collections.abc import Callable
    from pathlib import Path

    from playwright.async_api import Locator, Page, ViewportSize

    from gflow_cli.api.transports.base import GenerationRequestRecorder, TransportSetup

# Lazy-imported at call time so ``import gflow_cli`` doesn't pay the
# Playwright import cost when another transport is selected.
try:  # pragma: no cover — re-bound at module import in production
    from playwright.async_api import async_playwright
except ImportError:  # pragma: no cover — Playwright is an install dependency
    async_playwright = None  # type: ignore[assignment]

log = structlog.get_logger(__name__)

# Type aliases for JSON-shaped ``cast(...)`` targets. Extracted so the quoted
# cast strings are not duplicated (SonarCloud S1192); a module-level alias keeps
# ruff's TC006 happy since the call sites pass a bare name, not a subscript.
_JsonObj = dict[str, Any]
_AnyList = list[Any]

# Flow editor entrypoint — ``?hl=en`` locks locale for selector stability.
FLOW_URL = "https://labs.google/fx/tools/flow?hl=en"
# URL fragment that distinguishes the project editor from the gallery.
_PROJECT_URL_FRAGMENT = "/project/"

# Image model picker (SOT flow-editor-map.json). Same arrow_drop_down trigger as
# video; options matched by product name.  Cascade discipline: Tier 1 (structural
# / ARIA) before Tier 2 (text).  The product names "Nano Banana 2", "Nano Banana
# Pro", and "Imagen 4" are Google-branded model identifiers that Flow does not
# localise across locales — the has-text() entries are therefore locale-stable.
# Primary locale control is ``locale=locale_env`` in launch_persistent_context
# (Playwright kwarg — persists across all in-session navigations including
# /project/<uuid> deep-links that drop the ?hl= param).  FLOW_URL's ``?hl=en``
# reinforces English on the initial load.  'Nano Banana 2' is not a substring of
# 'Nano Banana Pro', so has-text is unambiguous across the three.
# Tier 1 (structural) slots are reserved for data-* / aria-* anchors once a DOM
# probe via scripts/dev/capture_locale_invariants.py confirms stable attributes.
# Class-only carrier anchor (#730): `.google-symbols` matches the labs `<i>` AND the
# migrated `<mat-icon>`, which both carry the class — verified against a real CSS engine in
# tests/api/transports/test_ligature_carrier.py. The tag-qualified form matched ZERO on the
# migrated host, and this constant has neither a carrier twin nor a text fallback, so the
# miss was total and silent: the picker is best-effort, so generation simply proceeded on
# whatever tier the editor happened to open at.
IMAGE_MODEL_PICKER_TRIGGER = (
    "button[aria-haspopup='menu']:has(.google-symbols:text-is('arrow_drop_down'))"
)
# Verified live 2026-08-26 (menu read WHILE OPEN, profile denon82):
#   ['Nano Banana Pro', 'Nano Banana 2', 'Nano Banana 2 Lite']
# `has-text` is a SUBSTRING match, so 'Nano Banana 2' also matches
# 'Nano Banana 2 Lite' — text-is pins the exact label instead. The previous
# comment claimed the three names were mutually unambiguous; that was true when
# written and silently expired when Flow added the Lite tier.
# `Imagen 4` is NO LONGER OFFERED. Its selector is kept so the governance test
# reports an honest MISS (tests/flow_selectors/test_model_governance.py) rather
# than the model quietly disappearing from the registry.
IMAGE_MODEL_OPTION_SELECTORS: dict[Model, tuple[str, ...]] = {
    # `text-is` was tried first and REMOVED 2026-08-26: it never matched live.
    # The recorded inventory stores whitespace-NORMALISED labels, but `text-is`
    # matches raw innerText, which carries a newline between the emoji and the
    # label. Keeping a selector that only matches in the fixture would make the
    # governance test bless something that cannot work against Flow.
    Model.NARWHAL: ("[role='menuitem']:has-text('Nano Banana 2'):not(:has-text('Lite'))",),
    Model.GEM_PIX_2: ("[role='menuitem']:has-text('Nano Banana Pro')",),
    Model.HARBOR_SEAL: ("[role='menuitem']:has-text('Nano Banana 2 Lite')",),
    Model.IMAGEN_3_5: ("[role='menuitem']:has-text('Imagen 4')",),
}

# Image-mode tab inside the mode-switch dropdown.  Selectors are tried in
# order; the leading ``aria-controls`` matches are language-independent
# (Flow's accessibility wiring keeps the IMAGE token across locales),
# the ``has-text`` variants are Portuguese/English fallbacks, and the
# icon-ligature is a last resort.  Mirror of
# :data:`ui_automation_video.VIDEO_TAB_IN_MENU_SELECTORS`.
IMAGE_TAB_IN_MENU_SELECTORS = (
    "[role='menu'] [role='tab'][aria-controls*='IMAGE']",
    "[role='tab'][aria-controls*='IMAGE']",
    "[role='menu'] [role='tab']:has-text('Imagem')",
    "[role='menu'] [role='tab']:has-text('Image')",
    "[role='menu'] [role='tab']:has(i:text('image'))",
)

# Browser viewport — 1920×1080, the most common real desktop resolution (#315).
# Enlarged from 1280×800 to reduce the static-fingerprint signal; bigger stays in
# Flow's desktop layout (smaller would cross the responsive breakpoint and drift the
# selectors). NOTE: the sibling CG Worker assumes the old size — reconcile there
# separately. The REST client's own viewport
# (client.py, 1280×720) is an independent, selector-irrelevant context and is unchanged.
_VIEWPORT = {"width": 1920, "height": 1080}

# Hosts allowed when downloading generated PNGs. Flow's fifeUrl currently
# resolves to lh3.googleusercontent.com; the broader allow-list covers
# Google-owned redirect targets without leaking session cookies elsewhere.
# Suffix-match: "googleusercontent.com" matches "lh3.googleusercontent.com".
_ALLOWED_DOWNLOAD_HOST_SUFFIXES: tuple[str, ...] = (
    "googleusercontent.com",
    "googleapis.com",
    "google.com",
    # Agentic cohort: the tRPC redirect URL (media.getMediaUrlRedirect) is
    # same-origin with labs.google — session cookies authorise the download.
    "labs.google",
    # Migrated flow.google.com host: results are signed CDN URLs on this host
    # (Expires + KeyName=labs-flow-prod-cdn-key + Signature), measured 2026-09-05.
    "flow-content.google",
)


def _is_allowed_download_host(url: str) -> bool:
    """True if ``url``'s host ends with one of the allowed Google domains.

    Refuses URLs that lack a host or use a non-https scheme — both shapes
    are unexpected for Flow-issued fifeUrls and treating them as suspect
    is safer than treating them as trustworthy.
    """
    try:
        parsed = urlparse(url)
    except (ValueError, TypeError):
        return False
    if parsed.scheme != "https" or not parsed.hostname:
        return False
    host = parsed.hostname.lower()
    return any(
        host == suffix or host.endswith("." + suffix) for suffix in _ALLOWED_DOWNLOAD_HOST_SUFFIXES
    )


async def _capture_debug_screenshot(
    page: Any,
    out_dir: Path | None,
    filename: str,
) -> Path | None:
    """Best-effort viewport screenshot for debug troubleshooting.

    Writes to ``out_dir / filename`` and returns the path, or ``None``
    when ``out_dir`` is not provided. Captures only the current viewport
    (``full_page=False``) to bound the PII surface — even a viewport
    screenshot of a logged-in Flow page includes the user's avatar /
    email indicator in the top-right corner, so a warning is logged so
    the operator knows the file may contain identifying information.

    Failures during screenshot capture are swallowed — debugging aids
    must not become a second source of exceptions during a real failure.
    """
    if out_dir is None:
        return None
    out_dir.mkdir(parents=True, exist_ok=True)
    shot_path = out_dir / filename
    try:
        await page.screenshot(path=str(shot_path), full_page=False)
        log.warning(
            "ui_automation.debug_screenshot_may_contain_pii",
            path=str(shot_path),
            note=(
                "viewport may include account avatar / email indicator from "
                "the authenticated Google session"
            ),
        )
    except Exception as e:
        log.debug("ui_automation.screenshot_capture_failed", error=str(e))
        return None  # never report a path that was not written (#283)
    return shot_path


# Prompt input selectors — Slate.js editor is the canonical target on
# Flow's editor page; the contenteditable/textarea fallbacks cover UI
# evolutions.
PROMPT_INPUT_SELECTORS = (
    'div[role="textbox"][data-slate-editor="true"]',
    'div[contenteditable="true"]',
    "textarea",
    '[aria-label*="prompt"]',
)

# Submit button selectors — all entries are locale-stable.
# The ``arrow_forward`` ligature is a Material Symbols icon name (not a UI
# label), so it renders identically regardless of the Chrome profile locale.
# Use :text() inside :has() (not :has-text() which is invalid inside :has()).
# Class-only carrier anchor (#730). `.google-symbols` covers the labs `<i>` and the migrated
# `<mat-icon>` alike — both carry the class, verified against a real CSS engine in
# tests/api/transports/test_ligature_carrier.py.
#
# This cascade was WORKING BY LUCK on the migrated host. Entries 0 and 1 were tag-qualified
# and matched nothing there; the submit only ever landed because entry 2 matches the
# `<mat-icon>`'s *text*. Observed live 2026-09-07:
# `prompt_submitted via="button:has-text('arrow_forward')"`. Two misses at ~2s each were
# paid on every submit before the fallback rescued it.
#
# The old `button:has(i:text(...))` entry is deleted, not kept: with entry 0 class-only it is
# strictly dominated — anything a bare `<i>` carrying that text could match, the class-only
# form matches too, and an `<i>` WITHOUT the class is not an icon carrier.
# `:text-is` (exact), NOT `:text` (substring). The old entry was
# `i.google-symbols:text('arrow_forward')`, whose substring match also accepts
# `arrow_forward_ios` — a real Material Symbol. The `<i>` qualifier happened to contain that
# on labs; dropping it for the class-only carrier made the over-match reachable, and the
# two-carrier fixture caught it as `matched 3 of 2` before it ever ran live. Same trap as
# `:text('upload')` accepting `drive_folder_upload` ([[flow-locale-leak-icon-ligatures]]).
SUBMIT_BUTTON_SELECTORS = (
    "button:has(.google-symbols:text-is('arrow_forward'))",
    "button:has-text('arrow_forward')",
)

# Prompt-format button in the character editor ("Format" in EN) — rewrites the
# typed prompt into Flow's character prompt-engineering shape.
#
# Live DOM, two frontends, two captures by scripts/dev/spike_character_prompt_format.py:
#
#   labs      2026-07-27:  <button disabled>
#                            <i class="... google-symbols ...">personal_recommendations</i>
#                            <span>Format</span></button>
#   migrated  2026-09-07:  <flow-format-prompt-button>
#                            <button ... aria-label="Formatar">
#                              <mat-icon class="... google-symbols ...">
#                                personal_recommendations</mat-icon>
#                              <span>Formatar</span></button></flow-format-prompt-button>
#
# Same ligature, different carrier tag (`<i>` vs `<mat-icon>`) — and the label is
# localised on both, so it is never an anchor. Hence: custom element first, then the
# ligature under either carrier. Full evidence, including why the EN `span:text-is`
# fallback was deleted rather than translated, in
# docs/superpowers/spikes/2026-09-07-character-format-button-anchor.md.
#
# The button ships `disabled` while the prompt box is empty (both hosts) — see
# :meth:`UiAutomationTransport.format_character_prompt` for why that matters.
#
# `:text()` not `:has-text()` (invalid inside `:has()`); `text-is` exact match so a
# longer ligature cannot partial-match.
# Observed-rewrite gate for the Format button (#727). Flow rewrites SERVER-SIDE:
# measured 2026-09-07 on the migrated host, the reshaped text reached the composer
# at ~5.4s. The budget is deliberately generous rather than fitted to that single
# sample -- the costs are asymmetric. Too long is bounded latency on an opt-in flag
# whose expiry falls back to exactly the old behaviour; too short silently
# reintroduces the bug, invisibly, which is what shipped. `elapsed_ms` is logged on
# every success so a real distribution accrues in production instead of being
# guessed here from n=1.
_FORMAT_REWRITE_TIMEOUT_S = 30.0
# Jittered, like every other wait in this module: a fixed cadence is a
# deterministic signature in front of Google's anti-bot stack.
_FORMAT_REWRITE_POLL_MS = 250
# Slate/ProseMirror re-render and normalise whitespace, so a bare `!=` fires on
# churn. Normalisation moves the length by a handful of characters; the observed
# rewrite moved it by 632 (19 -> 651). 16 sits far above the former and far below
# the latter.
_FORMAT_REWRITE_MIN_DELTA = 16

PROMPT_FORMAT_SELECTORS: tuple[str, ...] = (
    "flow-format-prompt-button button",
    "button:has(mat-icon:text-is('personal_recommendations'))",
    "button:has(i.google-symbols:text-is('personal_recommendations'))",
    "button:has(i:text-is('personal_recommendations'))",
)

# Self-contained, locale-independent triptych instruction for body generation.
# Live-verified 2026-06-02: produces a consistent front/side/back body image in ONE
# generation, seeded by the auto-attached face reference. We replace Flow's own
# (localized) pre-filled template with this rather than depending on reading/parsing it.
_BODY_TRIPTYCH_PREAMBLE = (
    "Full-body triptych in three angles: front, side (3/4), and back. "
    "High resolution, uniform studio lighting, consistent anatomical proportions "
    "across all angles, solid white background. "
)

# Body-mode settle gate — two-button character editor ("Portrait" / "Create
# Body", observed live 2026-07-25/26 on 0.43.0). When the switch has not
# settled, typing can land in the PORTRAIT composer and Flow autosaves the
# corruption via PATCH /v1/flowWorkflows/{id}. Current Flow reuses one Slate
# box; the auto-attached face reference proves it belongs to body mode. Legacy
# cohorts mount a second Slate box, detected by the count rising. Both signals
# are structural, never localized button text.
_BODY_SLOT_MOUNT_TIMEOUT_S = 10.0
_BODY_SLOT_MOUNT_POLL_MS = 250

# "+ New project" CTA selectors.  Cascade discipline: structural / icon-first
# (locale-stable) before localised text fallbacks spanning all 14 supported
# locales.  The ``add_2`` Material Symbols ligature is locale-invariant — the
# icon-class tier is tried first so this selector works even when the Chrome
# profile runs in a non-English locale.  The ``[role='button']`` ARIA-role
# variant of the icon anchor covers host elements that are not ``<button>``
# tags.  The anchored ``^\+\s+\S+$`` regex matches "+ <single-word>" buttons
# only — anchoring prevents matching e.g. "+ Filter" or "+ Add member" rows
# that contain extra words.  Text variants are ordered by onboarding-locale
# list (same 14 as ``ONBOARDING_SELECTORS``).
#
# LABS-ONLY BY MEASUREMENT, not by intent. The migrated `flow.google.com` frontend renders
# the ligature `add` and renders `add_2` NOWHERE — composer add=1/add_2=0, editor
# add=2/add_2=0, per-surface controls passing (2026-09-07,
# docs/superpowers/spikes/2026-09-07-ligature-carrier-and-name-drift.md). This is a ligature
# NAME drift, not the carrier split #730 fixed, so adding a `mat-icon` twin would not help.
#
# It is harmless today only because no migrated path reaches here: `migrated_can_serve`
# refuses without a `project_id`, `ensure_editor` navigates straight to the project URL, and
# `character create` requires `--project`. Those guards are what a future port relaxes — so
# `_enter_editor` now names the host rather than blaming this cascade when it is reached.
NEW_PROJECT_SELECTORS = (
    # Tier 1 — structural / icon: locale-invariant.
    # The migrated `flow.google.com` gallery renders the CTA with the ligature **`add`**,
    # under a `<mat-icon>`, and renders `add_2` nowhere on that surface (measured
    # 2026-09-07, denon82, control 47 ligature nodes). Class-only so one entry covers both
    # carriers. Listed FIRST because without it every Tier-1 entry below misses there and
    # the CTA survives only on the English text fallback — which is the anti-pattern this
    # tier exists to avoid, and which fails outright on a non-EN migrated profile.
    "button:has(.google-symbols:text-is('add'))",
    "[role='button']:has(.google-symbols:text-is('add'))",
    "button:has(.google-symbols:text-is('add_2'))",
    "[role='button']:has(.google-symbols:text-is('add_2'))",
    # `button:text-matches('^\+\s+\S+$', 'i')` used to sit here. It is not a valid
    # Playwright selector and RAISES on every evaluation — measured twice against the live
    # gallery, both runs `ERR Error`. `except Exception: continue` in the sweep swallowed
    # that, so it has never matched anything on any host while costing a round trip per
    # attempt. Deleted rather than repaired: the `add` anchor above is what the "+ <word>"
    # regex was reaching for, and it is structural rather than a text shape.
    # Tier 2 — localised text: 14 locales (EN / PT / ES / FR / DE / IT / NL /
    # JA / ZH / KO / PL / RU / TR / ID).
    "button:has-text('New project')",  # EN
    "button:has-text('Novo projeto')",  # PT
    "button:has-text('Nuevo proyecto')",  # ES
    "button:has-text('Nouveau projet')",  # FR
    "button:has-text('Neues Projekt')",  # DE
    "button:has-text('Nuovo progetto')",  # IT
    "button:has-text('Nieuw project')",  # NL
    "button:has-text('新しいプロジェクト')",  # JA
    "button:has-text('新建项目')",  # ZH (Simplified)
    "button:has-text('새 프로젝트')",  # KO
    "button:has-text('Nowy projekt')",  # PL
    "button:has-text('Новый проект')",  # RU
    "button:has-text('Yeni proje')",  # TR
    "button:has-text('Proyek baru')",  # ID
)

# Onboarding bypass — cookie banners, GDPR consent dialogs, landing-page CTAs.
# Cascade discipline: structural/ARIA anchors (Tier 1) before localised text
# (Tier 2).  Every entry is best-effort: _bypass_onboarding swallows misses.
#
# Tier 1 — structural / ARIA: locale-invariant regardless of the Chrome
# profile's display language.
#   • Google Funding Choices / GDPR consent SDK sets button#L2AGLb and
#     aria-label="Accept all" / aria-label="I agree" in English even when
#     the *button text* is translated — these are programmatic SDK constants,
#     not UI strings.
_ONBOARDING_STRUCTURAL_SELECTORS: tuple[str, ...] = (
    "button#L2AGLb",  # Google consent SDK "Accept all"
    "button[aria-label='Accept all']",  # consent SDK ARIA name (exact)
    "button[aria-label='I agree']",  # consent SDK ARIA name (exact)
)

# Tier 2 — localised text / language-dependent ARIA: extends coverage to
# the 14 locales most likely to be used with Flow.  Not locale-invariant,
# but maximises the fallback surface for users who hit onboarding before
# entering the editor.  Includes two case-insensitive ARIA-partial entries
# (`aria-label*='Accept' i` / `*='Agree' i`) at the head: these match many
# CMP dialogs (OneTrust, Cookiebot) whose aria-label values stay in English
# even on non-EN pages, but English ARIA values are not guaranteed across
# every CMP so they live here rather than in the strict structural tier.
_ONBOARDING_TEXT_SELECTORS: tuple[str, ...] = (
    # English-language ARIA partial catches (OneTrust, Cookiebot, etc. often
    # use English aria-label values even on non-EN pages, but this is not
    # guaranteed, so these belong here rather than in the structural tier).
    "button[aria-label*='Accept' i]",  # broader CMP ARIA catch (en)
    "button[aria-label*='Agree' i]",  # broader CMP ARIA catch (en)
    # EN
    "button:has-text('Accept all')",
    "button:has-text('Agree')",
    "button:has-text('I agree')",
    "button:has-text('Accept')",
    "button:has-text('Create with Flow')",
    "button:has-text('Get Started')",
    # PT (Brasil / Portugal)
    "button:has-text('Aceitar tudo')",
    "button:has-text('Aceitar')",
    "button:has-text('Concordo')",
    "button:has-text('Criar com o Flow')",
    "button:has-text('Começar')",
    # DE
    "button:has-text('Alle akzeptieren')",
    "button:has-text('Zustimmen')",
    "button:has-text('Ich stimme zu')",
    "button:has-text('Loslegen')",
    # ES
    "button:has-text('Aceptar todo')",
    "button:has-text('Aceptar')",
    "button:has-text('Acepto')",
    "button:has-text('Comenzar')",
    # FR
    "button:has-text('Tout accepter')",
    "button:has-text('Accepter')",
    'button:has-text("J\'accepte")',
    "button:has-text('Commencer')",
    # IT
    "button:has-text('Accetta tutto')",
    "button:has-text('Accetto')",
    "button:has-text('Inizia')",
    # NL
    "button:has-text('Alles accepteren')",
    "button:has-text('Akkoord')",
    # JA
    "button:has-text('すべて同意する')",
    "button:has-text('同意する')",
    "button:has-text('はじめる')",
    # ZH (Simplified)
    "button:has-text('全部接受')",
    "button:has-text('接受')",
    "button:has-text('开始使用')",
    # KO
    "button:has-text('모두 동의')",
    "button:has-text('동의')",
    "button:has-text('시작하기')",
    # PL
    "button:has-text('Zaakceptuj wszystko')",
    "button:has-text('Zgadzam się')",
    # RU
    "button:has-text('Принять всё')",
    "button:has-text('Принять')",
    # TR
    "button:has-text('Tümünü kabul et')",
    "button:has-text('Kabul et')",
    # ID (Indonesian)
    "button:has-text('Setujui semua')",
    "button:has-text('Setujui')",
)

# Combined public tuple — structural first, text fallbacks after.
# Import this; use _ONBOARDING_STRUCTURAL_SELECTORS / _ONBOARDING_TEXT_SELECTORS
# only when testing cascade ordering.
ONBOARDING_SELECTORS: tuple[str, ...] = (
    *_ONBOARDING_STRUCTURAL_SELECTORS,
    *_ONBOARDING_TEXT_SELECTORS,
)

# Changelog / "What's new" iframe selectors — these src patterns match the
# gstatic CDN paths Flow uses for its release-note overlays. Two patterns are
# included: the /flow/ prefix form and the bare /changelogs/ form.
CHANGELOG_IFRAME_SELECTORS = (
    "iframe[src*='/flow/changelogs/']",
    "iframe[src*='/changelogs/']",
)

# Top banner / announcement selectors (#369).
#
# DO NOT add bare `[role='dialog']` or `[role='alert']` here. Both shipped
# briefly and broke `gflow character create` (#395): Flow's own working
# surfaces carry those roles, so `_detect_overlay` matched the app itself and
# `_dismiss_blocking_overlays` pressed Escape on the character composer. The
# generation then went out WITHOUT `entityContext`, and Flow filed the portrait
# as a plain project image with no `parentEntityId` — a silent, credit-spending
# failure. Proven live 2026-07-28: with those two selectors removed, the very
# same command bound the character on the first try (`entity_patched`, real
# `thumbnail_media_id`); with them present it failed every run.
#
# Top banner / announcement selectors (#369, #403).
#
# DO NOT add bare `[role='dialog']` or `[role='alert']` here. Both shipped
# briefly and broke `gflow character create` (#395): Flow's own working
# surfaces carry those roles, so `_detect_overlay` matched the app itself and
# `_dismiss_blocking_overlays` pressed Escape on the character composer.
#
# Overlay detection is strictly language-agnostic, anchoring on DOM roles,
# structural element tags, and href attributes rather than localized text.
TOP_BANNER_SELECTORS: tuple[str, ...] = (
    "[role='banner']",
    "a[href*='changelog']",
    "a[href*='changelogs']",
)

# Close-button selectors tried after a changelog iframe or banner overlay is detected.
# Ordered from most-specific to most-generic so a precise match wins first.
# All are tried before the Escape fallback.
OVERLAY_CLOSE_BUTTON_SELECTORS: tuple[str, ...] = (
    "[role='dialog']:has(a[href*='changelog']) button",
    "button:has(i.google-symbols:text('clear'))",
    "button:has(i:text('clear'))",
    "button:has(i.google-symbols:text('close'))",
    "button:has(i:text('close'))",
    "[role='dialog'] button:has(i:text('close'))",
    "button[data-dismiss]",
)

# #593 split of the cascade above. The first entry requires a changelog link inside
# the dialog, so it cannot match one of Flow's own surfaces and is safe to try on any
# page. The rest are generic enough to match app chrome and only run once the page is
# known to be blocked.
_CHANGELOG_SCOPED_CLOSE: tuple[str, ...] = OVERLAY_CLOSE_BUTTON_SELECTORS[:1]
_GENERIC_CLOSE: tuple[str, ...] = OVERLAY_CLOSE_BUTTON_SELECTORS[1:]

# Detectors for the splash screen or welcome overlay (pure structural anchors).
WELCOME_SCREEN_SELECTORS: tuple[str, ...] = (
    "[role='dialog']:has(a[href*='flow'])",
    "[role='dialog']:has(a[href*='changelog'])",
)

# Selector-free block probe (#593). `pointer-events: none` on the body is what an
# overlay does to the app behind it; it is not tied to any announcement's markup,
# copy, or locale. Used three ways: as the gate that keeps the destructive Escape
# fallback off working surfaces (#395), as the post-dismissal verification, and as
# the post-mortem detail on a timeout.
_BLOCK_PROBE_JS = """
() => ({
  pointerEvents: getComputedStyle(document.body).pointerEvents,
  dialogs: document.querySelectorAll("[role='dialog'],[role='alertdialog'],dialog").length,
})
"""


# Generation settings trigger — the SAME unified button as the mode-switch
# dropdown: a ``button[aria-haspopup='menu']`` carrying the current ratio
# ``crop_*`` icon. The ``aria-haspopup='menu'`` qualifier is REQUIRED — without
# it any icon-only aspect thumbnail in the just-opened panel can match, causing
# a click on the wrong element and a ``gen_settings_panel_not_found`` skip that
# leaves Flow's own default count in effect (typically 2 concurrent requests
# billed while the CLI downloads only 1). Aliased to
# ``MODE_SWITCH_TRIGGER_SELECTORS`` so the two call sites stay a single source
# of truth (see [[image-video-mode-switch-symmetry]]).
GEN_SETTINGS_BUTTON_SELECTORS = MODE_SWITCH_TRIGGER_SELECTORS

# CLI string → ordered list of candidate tab labels to try in the Flow gen
# settings panel. Most ratios are labelled with their colon-numeric form
# ("16:9"), but the "1:1" tab is sometimes rendered as "Square" or "1×1"
# (multiplication sign U+00D7) — we try a small cascade and the first
# locator that becomes visible wins.
_ASPECT_TAB_CANDIDATES: dict[str, tuple[str, ...]] = {
    "16:9": ("16:9",),
    "9:16": ("9:16",),
    "1:1": ("1:1", "Square", "1×1", "1x1"),
    "4:3": ("4:3",),
    "3:4": ("3:4",),
}

# Supported image-count values for the xN selector.
_SUPPORTED_COUNTS: frozenset[int] = frozenset({1, 2, 3, 4})

# Number of count tabs Flow renders in the settings panel (1 through 4).
_COUNT_TAB_COUNT = 4

# Structured event name emitted at every exit path of `_set_count`.
# Extracted to a module-level constant to satisfy SonarCloud S1192
# (duplicate literal) and keep the spelling consistent across log sites.
_EVT_COUNT_SETTER_COMPLETED = "ui_automation.count_setter_completed"

# Structured event name emitted at every overlay-dismissal exit path.
# Extracted to a module-level constant to satisfy SonarCloud S1192.
_EVT_OVERLAY_DISMISSED = "ui_automation.overlay_dismissed"

# Regex that matches count-tab text exactly, across BOTH label cohorts:
# legacy "1x"/"x2"/"x3"/"x4" and the renamed "x1"/"x2"/"x3"/"x4" observed
# live 2026-07-31 (issue #404 — Flow unified the labels to xN, which made the
# old `^(1x|x[2-4])$` filter silently drop the count-1 tab).
# These are the ONLY role="tab" elements whose text fits this pattern —
# Mode tabs ("image\nImagem") and Aspect tabs ("16:9", "crop_square") do not.
# The pattern is locale-invariant: Flow never translates the digit+x label.
_COUNT_TAB_TEXT_RE = re.compile(r"^(1x|x[1-4])$")

# Subdirectory inside out_dir where diagnostic artefacts are written.
# Keeps count_before/after screenshots and DOM dumps out of the user-facing
# output directory so file-count assertions on *.png never pick them up.
_DIAGNOSTICS_SUBDIR = "_diagnostics"


def _count_tabs_locator(page: Page) -> Locator:
    """Return a Playwright Locator that matches ONLY the 4 count tabs.

    Filters ``role="tab"`` elements by text matching :data:`_COUNT_TAB_TEXT_RE`
    (legacy ``1x``/``x2``/``x3``/``x4`` and renamed ``x1``/``x2``/``x3``/``x4``,
    issue #404). The pattern is unique to count tabs — Mode tabs and Aspect
    tabs never match it — so the filter survives all three Radix tablists
    being present in the DOM simultaneously.

    DOM evidence: ``tmp/dom_dump.json`` (profile denon82, pt-BR, 2026-05-22)
    for the legacy cohort; ``scripts/dev/spike_issue404_count_tabs_recon.py``
    output (profile ffroliva, 2026-07-31) for the renamed cohort.
    """
    return page.locator('[role="tab"]').filter(has_text=_COUNT_TAB_TEXT_RE)


def _count_tab_locator_for(page: Page, count: int) -> Locator:
    """Locator for THE count tab carrying digit ``count``.

    Keyed on the digit in the label rather than position, so it survives the
    label-cohort rename (legacy ``1x`` → current ``x1``, issue #404) and any
    reordering/shrinking of the filtered tab set.
    """
    return page.locator('[role="tab"]').filter(has_text=re.compile(rf"^({count}x|x{count})$"))


# Reverse map: domain Aspect enum → CLI string accepted by the settings panel.
_CLI_FROM_ASPECT: dict[Aspect, str] = {
    Aspect.PORTRAIT: "9:16",
    Aspect.LANDSCAPE: "16:9",
    Aspect.SQUARE: "1:1",
    Aspect.LANDSCAPE_FOUR_THREE: "4:3",
    Aspect.PORTRAIT_THREE_FOUR: "3:4",
}


def aspect_cli_from_enum(aspect: Aspect) -> str | None:
    """Map the domain Aspect enum to the CLI string the settings panel expects."""
    return _CLI_FROM_ASPECT.get(aspect)


# Back-compat alias — kept so any remaining internal callers and the existing
# test imports work without a rename sweep.
def _prompt_hash_stable(text: str) -> str:
    """Truncated sha256 matching image_batch._prompt_hash prefix length.

    Inlined here to avoid src/gflow_cli/api/transports importing image_batch
    (would create a circular dependency). 8-char prefix is sufficient for
    structlog event correlation within a single batch run.
    """
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:8]


def _extract_project_id(url: str) -> str | None:
    """Thin alias for `extract_project_id` from `_common`.

    Kept for back-compat with any existing call sites and tests that import
    the private name directly from this module.
    """
    return extract_project_id(url)


def _collect_images_from_body(body: dict[str, Any], images: list[GeneratedImage]) -> None:
    """Append parseable GeneratedImage entries from one batchGenerateImages body."""
    media_list_raw = body.get("media", [])
    if not isinstance(media_list_raw, list):
        return
    for item_raw in cast(_AnyList, media_list_raw):
        if not isinstance(item_raw, dict):
            continue
        item: dict[str, Any] = cast(_JsonObj, item_raw)
        try:
            # Parse a one-item full response so the sibling ``workflows[]``
            # metadata is joined by workflow id.  Parsing the media item alone
            # drops Flow's ``displayName`` — the browser picker's search key.
            parsed = GeneratedImage.from_response_dict(
                {"media": [item], "workflows": body.get("workflows", [])}
            )
            images.extend(parsed)
        except ValueError as e:
            log.warning("ui_automation.parse_media_item_failed", error=str(e))


def _images_from_responses(
    responses: list[dict[str, Any]],
) -> tuple[list[GeneratedImage], int | None, str, dict[str, Any]]:
    """Process captured batchGenerateImages responses.

    Returns ``(images, first_error_status, first_error_route, first_error_body)``.
    Raises :class:`AuthExpiredError` on 401, :class:`WafRejectionError` on 403,
    and :class:`RateLimitError` on 429, which the caller must surface — these are
    not first-error candidates.

    The error **body** rides out with the status (issue #528): the caller has to
    tell a content-policy 400 apart from a genuinely unexpected response shape,
    and dropping the body here left it no way to.
    """
    images: list[GeneratedImage] = []
    first_error_status: int | None = None
    first_error_route: str = ""
    first_error_body: dict[str, Any] = {}

    for response in responses:
        status = response.get("status")
        body: dict[str, Any] = cast(_JsonObj, response.get("body") or {})
        route_str: str = str(response.get("url", ""))

        if status == 401:
            raise AuthExpiredError(
                detail="batchGenerateImages returned HTTP 401 — session expired",
                status=401,
                route=route_str,
            )
        if status == 403:
            log.warning(
                "ui_automation.batch_403_body",
                body_prefix=str(body)[:200],
                route=route_str,
            )
            raise WafRejectionError(
                detail=(
                    "batchGenerateImages HTTP 403 — reCAPTCHA score too low or WAF "
                    "fingerprint mismatch. Re-authenticate and retry."
                ),
                status=403,
                route=route_str,
            )
        if status == 429:
            retry_after = parse_retry_after(response)
            log.warning(
                "ui_automation.batch_429_body",
                body_prefix=str(body)[:200],
                route=route_str,
                retry_after=retry_after,
            )
            raise RateLimitError(
                detail=(
                    "batchGenerateImages HTTP 429 — rate limit hit."
                    + (f" Retry after {retry_after:.0f}s." if retry_after is not None else "")
                ),
                status=429,
                route=route_str,
                retry_after=retry_after,
            )
        if status != 200:
            if status == 400:
                # We still do not know Flow's real 400 shape on this route — every
                # #528 incident bundle showed a bare `{"status": 400}`. Log it like
                # the 403 branch above so the next occurrence settles it.
                log.warning(
                    "ui_automation.batch_400_body",
                    body_prefix=str(body)[:200],
                    route=route_str,
                )
            if first_error_status is None:
                first_error_status = status
                first_error_route = route_str
                first_error_body = body
            continue

        _collect_images_from_body(body, images)

    return images, first_error_status, first_error_route, first_error_body


_REF_VALUE_MAX_CHARS = 512


def _elide_large_value(value: Any) -> Any:
    """Return *value* verbatim when small, else a length-only redaction marker.

    Guards the request-body logger against dumping large/secret payloads: if Flow
    names an i2i image field `reference*`/`*entity*`, its base64 bytes would match
    the reference-field filter and be logged in full. Small fields like
    `referenceEntities` (a short list of `{entityId}`) pass through; anything
    serializing beyond the cap is elided to a `<elided N chars>` marker.
    """
    try:
        serialized = json.dumps(value, default=str)
    except (TypeError, ValueError):
        return f"<unserializable {type(value).__name__}>"
    if len(serialized) > _REF_VALUE_MAX_CHARS:
        return f"<elided {len(serialized)} chars>"
    return value


def _summarize_batch_request_body(post_data: str | None) -> dict[str, Any]:
    """Compact, byte-safe summary of an outgoing ``batchGenerateImages`` body.

    This is the make-or-break signal for the entity-reference spike: it reveals
    whether Flow's image submit carries a ``referenceEntities`` field after we
    attach a character via the picker — WITHOUT logging the full body (i2i
    bodies embed base64 image bytes that would flood the log and leak content).

    Returns a dict with ``present``, ``mentions_reference_entities`` (cheap
    substring probe that survives non-JSON bodies), and — when the body parses —
    the keys of ``requests[0]`` plus any reference/entity-related fields verbatim
    (those are small id lists, safe to surface).
    """
    if not post_data:
        return {"present": False}
    summary: dict[str, Any] = {
        "present": True,
        "bytes": len(post_data),
        "mentions_reference_entities": "referenceEntit" in post_data,
    }
    try:
        parsed: object = json.loads(post_data)
    except (ValueError, TypeError):
        return summary
    if not isinstance(parsed, dict):
        return summary
    parsed_dict = cast(_JsonObj, parsed)
    reqs = parsed_dict.get("requests")
    if isinstance(reqs, list) and reqs and isinstance(reqs[0], dict):
        first = cast(_JsonObj, reqs[0])
        summary["request0_keys"] = sorted(first.keys())
        ref_bits = {
            k: _elide_large_value(v)
            for k, v in first.items()
            if "reference" in k.lower() or "entity" in k.lower()
        }
        if ref_bits:
            summary["reference_fields"] = ref_bits
    else:
        summary["top_keys"] = sorted(parsed_dict.keys())
    return summary


def _reference_field_count(post_data: str | None) -> int:
    """How many reference/entity-ish fields ride on ``requests[0]`` (issue #528).

    A COUNT, never the key names: this feeds the incident bundle, which retains
    counts and booleans only (§5.3, S02/S29). The deciding signal for a policy
    400 is how many face-bearing references were attached, not what they were
    called.
    """
    if not post_data:
        return 0
    try:
        parsed: object = json.loads(post_data)
    except (ValueError, TypeError):
        return 0
    if not isinstance(parsed, dict):
        return 0
    reqs = cast(_JsonObj, parsed).get("requests")
    if not (isinstance(reqs, list) and reqs and isinstance(reqs[0], dict)):
        return 0
    first = cast(_JsonObj, reqs[0])
    return sum(1 for k in first if "reference" in k.lower() or "entity" in k.lower())


def _entity_ids_from_one_request(req: Any) -> set[str]:
    """Extract entityId strings from a single ``requests[]`` entry."""
    if not isinstance(req, dict):
        return set()
    ents = cast(_JsonObj, req).get("referenceEntities")
    if not isinstance(ents, list):
        return set()
    out: set[str] = set()
    for ent in cast(_AnyList, ents):
        if isinstance(ent, dict):
            entity_id = cast(_JsonObj, ent).get("entityId")
            if isinstance(entity_id, str):
                out.add(entity_id)
    return out


def _entity_ids_from_request_body(post_data: str | None) -> set[str]:
    """Entity ids carried by an outgoing ``batchGenerateImages`` body.

    Request shape (live-verified — issue #170 report + movie spike):
    ``requests[].referenceEntities[].entityId``. Feeds the #170 submit
    backstop: a UI attach miss must not degrade to a text-only generation
    reported as success.
    """
    if not post_data:
        return set()
    try:
        parsed: object = json.loads(post_data)
    except (ValueError, TypeError):
        return set()
    if not isinstance(parsed, dict):
        return set()
    out: set[str] = set()
    reqs = cast(_JsonObj, parsed).get("requests")
    if not isinstance(reqs, list):
        return out
    for req in cast(_AnyList, reqs):
        out |= _entity_ids_from_one_request(req)
    return out


def _jitter_ms(base_ms: int, variance: float = 0.25) -> int:
    """Calculate a randomized delay around `base_ms` with `±variance` spread.

    Adds timing entropy to browser interaction delays to break deterministic Playwright
    automation fingerprints. Returns 0 if base_ms <= 0.
    """
    if base_ms <= 0:
        return 0
    delta = int(round(base_ms * max(0.0, min(1.0, variance))))
    return max(1, secrets.SystemRandom().randint(base_ms - delta, base_ms + delta))  # NOSONAR


class UiAutomationTransport(VideoGenerationMixin):
    """D.2.4 — Playwright UI mimicry strategy.

    Drives the Flow editor on a logged-in Pro/Ultra profile through a
    Playwright-managed persistent context. The strategy never exposes an
    external CDP debug port; Playwright's internal port is sufficient and
    keeps the browser environment indistinguishable from a typical
    developer session.

    Lifecycle (Protocol § 4.1)::

        await transport.setup(profile_dir)
        images = await transport.generate_images(project_id=..., request=...)
        await transport.teardown()
    """

    name = "ui_automation"

    async def _wait_jitter(self, page: Page, base_ms: int, variance: float = 0.25) -> None:
        """Wait for a jittered duration using page.wait_for_timeout."""
        jittered = _jitter_ms(base_ms, variance=variance)
        if jittered > 0:
            await page.wait_for_timeout(jittered)

    def __init__(self) -> None:
        self._pw_cm: Any | None = None
        self._ctx: Any | None = None
        self._page: Page | None = None
        self._setup_done: bool = False
        self._owns_playwright: bool = False
        # #792: set when a migrated run FAILED, so the park that would otherwise
        # run in a `finally` is deferred past FlowApiClient's incident capture.
        self._deferred_park_pending: bool = False
        # Cross-process profile lease (D3). Held ONLY on the standalone-context
        # path (setup with page=None), where this transport owns the persistent
        # context. On the shared-page path the caller (FlowApiClient) owns both
        # the context and the lease, so this stays None.
        self._lease: ProfileLease | None = None
        # Typed output/storage wiring handed in by FlowApiClient through the
        # public apply_setup() seam (SupportsTransportSetup). The private slots
        # below are this transport's own derived state — the client no longer
        # writes them directly.
        self.setup_config: TransportSetup | None = None
        # Counts-only incident sink for outgoing generation submits (#528).
        # None until apply_setup runs, and whenever incident capture is off.
        self._record_generation_request: GenerationRequestRecorder | None = None
        # Account locale segment injected by the client (#580). None => bare URLs.
        self._account_locale: str | None = None
        # Optional directory for debug screenshots — derived from the client's
        # `out_dir` constructor arg (#18). When None, the internal
        # _capture_debug_screenshot helper is a no-op.
        self._out_dir: Path | None = None
        # Optional cloud-storage configuration. Video downloads read these slots
        # inside VideoGenerationMixin._download_video.
        self._storage_uri: str | None = None
        self._output_dir: Path | None = None
        # Serialize concurrent generate_images calls — a single Playwright Page
        # cannot be safely shared across parallel asyncio tasks (each call
        # navigates, opens panels, and types into the same DOM). The lock
        # converts the N-parallel fan-out from generate_images_batch into N
        # sequential Page interactions, eliminating all race conditions.
        self._generate_lock: asyncio.Lock = asyncio.Lock()

    def apply_setup(self, config: TransportSetup) -> None:
        """Accept output/storage wiring publicly (SupportsTransportSetup seam).

        Stores the immutable record and derives the private slots the debug-
        screenshot and video-download paths read. ``out_dir`` is only adopted
        when set, preserving the prior "don't clobber with None" plumbing
        behaviour; ``storage_uri``/``output_dir`` mirror the config as-is.
        """
        self.setup_config = config
        if config.out_dir is not None:
            self._out_dir = config.out_dir
        self._storage_uri = config.storage_uri
        self._output_dir = config.output_dir
        self._record_generation_request = config.record_generation_request
        self._account_locale = config.account_locale

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def setup(self, profile_dir: Path, *, page: Page | None = None) -> None:
        """Acquire a Page on the logged-in Flow editor.

        Idempotent — second call is a no-op.

        When ``page`` is provided (shared-page path), the caller owns the
        Playwright lifecycle; teardown() will not close the context. When
        ``page`` is None, the strategy opens its own persistent context
        against ``profile_dir`` and is responsible for its full lifecycle.

        An initial ``page.goto(FLOW_URL)`` is attempted; a navigation
        failure is logged but not raised — auth/UI recovery happens in
        ``generate_images``.
        """
        if self._setup_done:
            return

        if page is not None:
            # Shared-page path: caller owns Playwright lifecycle.
            self._page = page
            self._owns_playwright = False
            self._setup_done = True
            log.info("ui_automation.setup_shared_page")
            return

        # Engine selection (standalone-context path; the shared-page path above
        # already returned). Default playwright keeps the module symbol; only the
        # opt-in patchright engine routes through the resolver.
        from gflow_cli.api._engine import (
            active_engine,
            close_context_bounded,
            log_engine_selected,
            resolve_async_playwright,
        )
        from gflow_cli.config import BrowserEngine

        engine = active_engine()
        log_engine_selected(engine)
        if engine == BrowserEngine.PATCHRIGHT:
            pw_factory = resolve_async_playwright(engine)
        elif async_playwright is None:  # pragma: no cover — install-time guard
            msg = (
                "Playwright is required for UiAutomationTransport. "
                "Install via `uv sync` (it is a runtime dependency)."
            )
            raise RuntimeError(
                msg,
            )
        else:
            pw_factory = async_playwright

        pw_cm = pw_factory()
        # The two engines (playwright | patchright) expose a structurally identical
        # ``.chromium.launch_persistent_context`` surface; type as Any so this
        # standalone path is engine-agnostic without per-engine stubs.
        pw: Any = await pw_cm.__aenter__()
        ctx = None
        try:
            import os

            from gflow_cli.browser_manager import (
                channel_for_profile,
                ensure_profile_engine_compatible,
                window_position_args,
            )
            from gflow_cli.config import get_settings

            # Own the profile BEFORE Chrome launches (D3). Contention raises
            # ProfileLockedError here; the except below tears the driver back
            # down. aacquire so a #478 opt-in wait polls with asyncio.sleep
            # instead of blocking the event loop.
            self._lease = await ProfileLease(profile_dir).aacquire()
            locale_env = os.getenv("GFLOW_CLI_LOCALE", "en-US")
            channel = channel_for_profile(profile_dir)
            # #477: refuse a bundled-Chromium open of a profile last written by
            # a newer Chromium — downgrade cleanup can shred the session store.
            ensure_profile_engine_compatible(profile_dir, channel)
            ctx = await pw.chromium.launch_persistent_context(
                str(profile_dir),
                headless=False,
                viewport=cast("ViewportSize", _VIEWPORT),
                locale=locale_env,
                channel=channel,
                args=[
                    "--disable-blink-features=AutomationControlled",
                    "--password-store=basic",
                    "--disable-dev-shm-usage",
                    *window_position_args(get_settings().browser_window_position),
                ],
            )
            # Hide the automation flag so reCAPTCHA Enterprise doesn't score
            # the session as a bot — navigator.webdriver=true causes low-score
            # tokens and HTTP 403 on batchGenerateImages.
            await ctx.add_init_script(
                "Object.defineProperty(navigator,'webdriver',{get:()=>undefined})",
            )
            self._pw_cm = pw_cm
            self._ctx = ctx
            page = cast("Page", ctx.pages[0] if ctx.pages else await ctx.new_page())
            self._page = page
            try:
                await page.goto(FLOW_URL, wait_until="networkidle", timeout=45_000)
            except Exception as e:
                log.warning("ui_automation.flow_initial_goto_failed", error=str(e))
            self._owns_playwright = True
            self._setup_done = True
            log.info(
                "ui_automation.setup_own_context",
                profile_dir=str(profile_dir),
            )
        except BaseException:
            # Partial-setup leak guard. Catches BaseException (not just
            # Exception) so a CancelledError mid-setup ALSO tears down the
            # launched context (D4) — otherwise a cancelled launch would orphan
            # chrome and leak the lease. The context must be closed BEFORE the
            # driver exits — stopping only the driver leaves the detached
            # system-Chrome alive holding the profile dir (issue #293). Each
            # cleanup step is bounded + shielded so the cleanup itself cannot be
            # interrupted before the lease release; the original error re-raises.
            from gflow_cli.api._engine import (  # noqa: PLC0415
                CONTEXT_TEARDOWN_TIMEOUT_S,
                DRIVER_STOP_TIMEOUT_S,
                run_teardown_step,
            )

            if ctx is not None:
                await run_teardown_step(
                    close_context_bounded(ctx, owner="ui_automation"),
                    timeout=CONTEXT_TEARDOWN_TIMEOUT_S,
                    owner="ui_automation",
                    step="setup_context_close",
                )
            await run_teardown_step(
                pw_cm.__aexit__(None, None, None),
                timeout=DRIVER_STOP_TIMEOUT_S,
                owner="ui_automation",
                step="setup_driver_exit",
            )
            # Release the lease last — after context + driver are down (D3).
            if self._lease is not None:
                self._lease.release()
                self._lease = None
            raise

    # ------------------------------------------------------------------
    # Internal helpers — auth detection (unit 3.3)
    # ------------------------------------------------------------------

    @staticmethod
    async def _check_logged_in(page: Page) -> bool:
        """True if the page shows the authenticated Flow UI.

        Gates (pattern G13):
        - URL's host is one of Flow's own origins — ``labs.google`` or, since
          #639, the migrated ``flow.google.com``. Locale-stable: /fx/pt/tools/flow,
          /fx/es/tools/flow etc. all match, and so does the migrated /project/<id>.
        - /project/<uuid> URLs short-circuit to True (editor already open).
        - Otherwise reject if a top-level Sign-in CTA is visible.

        The host is PARSED and matched exactly. This gate used to be the
        substring test ``"labs.google" in page.url``, which any foreign URL
        satisfies simply by carrying the string in a path or query.

        A failure in the locator probe is treated as "no Sign-in button"
        — the URL gate already established Flow context, and a transient
        DOM error shouldn't force a re-auth loop.
        """
        if flow_host_kind(page.url) is None:
            return False
        if _PROJECT_URL_FRAGMENT in page.url:
            return True
        try:
            signin_button = await page.locator(
                "button:has-text('Sign in'), a:has-text('Sign in')",
            ).count()
        except Exception:
            signin_button = 0
        return signin_button == 0

    # ------------------------------------------------------------------
    # Internal helpers — gallery → editor navigation (unit 3.4)
    # ------------------------------------------------------------------

    async def _bypass_onboarding(self, page: Page) -> None:
        """Click through cookie banners and 'Get Started' pages if they appear."""
        for selector in ONBOARDING_SELECTORS:
            try:
                loc = page.locator(selector).first
                if await loc.is_visible(timeout=1000):
                    await loc.click(force=True)
                    log.info("ui_automation.onboarding_bypassed", selector=selector)
                    await page.wait_for_timeout(1000)
            except Exception:
                continue

    @staticmethod
    async def _probe_page_block(page: Page) -> dict[str, Any] | None:
        """Read whether the app behind any overlay is clickable. ``None`` = unreadable.

        Measured live on 2026-08-27 (#593): while Flow's announcement modal is up the
        body carries ``pointer-events: none`` and is neither ``aria-hidden`` nor
        ``inert`` — so every control reads visible and enabled yet never receives a
        click, and Playwright's actionability wait runs to timeout with no message.

        This is the only overlay signal that needs no selector: it is a property of
        being blocked, not of any particular announcement, so it holds for whatever
        Flow ships next and in any locale.
        """
        try:
            return await page.evaluate(_BLOCK_PROBE_JS)
        except Exception:  # noqa: BLE001 — a diagnostic must never break a run
            return None

    @classmethod
    async def _overlay_blocks_page(cls, page: Page) -> bool:
        """True when the app behind is unclickable. False also covers 'unreadable'."""
        state = await cls._probe_page_block(page)
        return bool(state and state.get("pointerEvents") == "none")

    @staticmethod
    async def _changelog_overlay_present(page: Page) -> bool:
        """True only for an *announcement* overlay — never for Flow's own surfaces.

        Narrower than :meth:`_detect_overlay` on purpose. A blocked body says
        something is covering the app, but Flow's own Radix menus and popovers set
        ``pointer-events: none`` on the body exactly the same way while they are open.
        Anything that acts on "blocked" alone would therefore fire mid-menu and close
        the panel it was meant to work in — the #395 shape, rediscovered.

        These two anchors cannot match a menu: both require a changelog link or the
        gstatic changelog iframe.
        """
        for sel in (*CHANGELOG_IFRAME_SELECTORS, "[role='dialog']:has(a[href*='changelog'])"):
            try:
                if await page.locator(sel).first.is_visible():
                    return True
            except Exception:  # noqa: BLE001 — a probe must never break a run
                continue
        return False

    @staticmethod
    async def _detect_overlay(page: Page) -> bool:
        """Return True if any changelog iframe, welcome screen, or top banner is visible."""
        for sel in CHANGELOG_IFRAME_SELECTORS + WELCOME_SCREEN_SELECTORS + TOP_BANNER_SELECTORS:
            try:
                if await page.locator(sel).first.is_visible(timeout=1500):
                    log.info("ui_automation.overlay_detected", selector=sel)
                    return True
            except Exception:
                continue
        return False

    @staticmethod
    async def _try_page_close_button(
        page: Page,
        selectors: tuple[str, ...] = OVERLAY_CLOSE_BUTTON_SELECTORS,
    ) -> bool:
        """Try each close selector at page level. Returns True on success.

        ``selectors`` is split by the caller (#593): the changelog-scoped anchor runs
        unconditionally, the generic ones only once the page is known to be blocked.
        """
        for close_sel in selectors:
            try:
                loc = page.locator(close_sel).first
                if await loc.is_visible(timeout=500):
                    await loc.click(force=True)
                    await page.wait_for_timeout(_jitter_ms(1000))
                    log.info(
                        _EVT_OVERLAY_DISMISSED,
                        selector=close_sel,
                        method="close_button_page",
                    )
                    return True
            except Exception:
                continue
        return False

    @staticmethod
    async def _try_iframe_close_button(page: Page) -> bool:
        """Try each close-button selector inside each changelog iframe. Returns True on success."""
        for iframe_sel in CHANGELOG_IFRAME_SELECTORS:
            try:
                frame = page.frame_locator(iframe_sel).first
                for close_sel in OVERLAY_CLOSE_BUTTON_SELECTORS:
                    loc = frame.locator(close_sel).first
                    if await loc.is_visible(timeout=500):
                        await loc.click(force=True)
                        await page.wait_for_timeout(_jitter_ms(1000))
                        log.info(
                            _EVT_OVERLAY_DISMISSED,
                            selector=close_sel,
                            method="close_button_frame",
                        )
                        return True
            except Exception:
                continue
        return False

    async def _require_unblocked(
        self,
        page: Page,
        out_dir: Path | None,
        *,
        epoch: str,
    ) -> None:
        """Abort pre-submit, at $0, when an overlay still covers the app (#593).

        The failure this replaces: every control reads visible and enabled, the click
        is dispatched, and Playwright's actionability wait runs to timeout — a bare
        ``TimeoutError`` naming nothing. A real ``gflow image t2i`` run died that way
        three navigations deep before the modal was dismissed by hand.

        Only a *persistent* block raises. Flow's own menus and dropdowns are Radix
        surfaces that set the same property while open, so a single reading would
        turn a transient into a hard failure; the re-probe after a settle is what
        separates "a menu is open" from "the app is unreachable".
        """
        if not await self._overlay_blocks_page(page):
            return
        await page.wait_for_timeout(_jitter_ms(1000))
        if not await self._overlay_blocks_page(page):
            return
        # One more dismissal before giving up. The boundary attempt can have run
        # BEFORE the dialog existed — Flow hydrates late — in which case the detector
        # saw nothing, dismissal was a no-op, and raising here would fail a run for a
        # modal that a single retry clears.
        await self._dismiss_blocking_overlays(page, out_dir)
        if not await self._overlay_blocks_page(page):
            return
        shot = await _capture_debug_screenshot(page, out_dir, "debug_overlay_still_blocking.png")
        raise UiSelectorDriftError(
            selector_drift_detail(
                "overlay_close_button",
                (
                    f"A Flow overlay is still covering the app after dismissal ({epoch}). "
                    "Controls below it read visible and enabled but cannot receive a "
                    "click. Open the project once in Chrome, dismiss the announcement, "
                    "then re-run — the dismissal persists on your account."
                ),
                shot,
            )
        )

    @classmethod
    async def _verify_overlay_cleared(cls, page: Page, *, method: str) -> bool:
        """Confirm the dismissal actually unblocked the app; report honestly if not.

        Before #593 this helper returned ``True`` the moment a click landed, so a
        dismissal that changed nothing still logged ``overlay_dismissed`` and the run
        then timed out somewhere unrelated — the success event lied, and two canary
        REDs were read as the wrong failure because of it.

        An unreadable probe counts as cleared: the pre-#593 optimism is the safer
        default when we genuinely cannot tell, and the caller still has its own waits.
        """
        state = await cls._probe_page_block(page)
        if state is None or state.get("pointerEvents") != "none":
            return True
        log.warning(
            "ui_automation.overlay_postmortem",
            method=method,
            pointer_events=state.get("pointerEvents"),
            dialogs=state.get("dialogs"),
            note=(
                "an overlay was dismissed but the app is still unclickable — the "
                "control the next step wants is covered, not missing"
            ),
        )
        return False

    @classmethod
    async def _dismiss_blocking_overlays(
        cls,
        page: Page,
        out_dir: Path | None = None,
    ) -> bool:
        """Dismiss Flow changelog / "What's new" iframes and any blocking overlays.

        Called at stable interaction boundaries (after editor navigation, before
        UI interactions that could be intercepted by a changelog popup).

        Strategy:
        1. Check whether any changelog iframe is currently visible.
        2. If none found, return False immediately (cheap; no log noise).
        3. If found, try each close-button selector in OVERLAY_CLOSE_BUTTON_SELECTORS.
           On first visible match: force-click it, log the selector used, return True.
        4. If no close button is discoverable, press Escape as a fallback and return True.
        5. If Escape raises (extremely rare — keyboard unavailable), capture a debug
           screenshot (if out_dir provided) and return False so the caller can decide
           how to proceed. The structured warning carries enough info to identify the
           blocking element.

        Returns True if a dismissal action was taken, False if the page was
        clear (no overlay) or if dismissal could not be confirmed.
        """
        if not await cls._detect_overlay(page):
            return False

        # The changelog-scoped anchor is safe on ANY page: it cannot match a dialog
        # that carries no changelog link, so it is tried before the block probe.
        if await cls._try_page_close_button(page, _CHANGELOG_SCOPED_CLOSE):
            return await cls._verify_overlay_cleared(page, method="close_button_page")

        # #395 guard, structural rather than advisory. Everything below is generic
        # enough to match Flow's own chrome: `button:has(i:text('close'))` fits the
        # character composer's own close button, and Escape is what actually caused
        # #395 — it closed the composer and the generation went out without
        # `entityContext`, billed and silently wrong.
        #
        # A page we can positively see is still clickable is not blocked by anything,
        # so none of it may run there. Only a positive reading disables the cascade:
        # when the probe is unreadable we keep the pre-#593 behaviour rather than
        # trading a known-good dismissal for a mystery timeout.
        #
        # Deliberate trade-off: an overlay that covers a control WITHOUT blocking the
        # body (a non-modal banner) is no longer auto-closed by the generic selectors.
        # That is the price of making #395 impossible, and it is the right side of the
        # trade — #395 spent real credits, whereas KNOWN_ISSUES rates the banner case
        # Low and transient.
        state = await cls._probe_page_block(page)
        if state is not None and state.get("pointerEvents") != "none":
            log.info(
                "ui_automation.overlay_skipped_page_clickable",
                pointer_events=state.get("pointerEvents"),
                dialogs=state.get("dialogs"),
                note="detector matched but the app is reachable — not an overlay to clear",
            )
            return False

        if await cls._try_page_close_button(page, _GENERIC_CLOSE):
            return await cls._verify_overlay_cleared(page, method="close_button_page")

        if await cls._try_iframe_close_button(page):
            return await cls._verify_overlay_cleared(page, method="close_button_frame")

        # Escape fallback (regression test case: iframe present, no close button).
        try:
            await page.keyboard.press("Escape")
            await page.wait_for_timeout(_jitter_ms(1000))
            log.info(
                _EVT_OVERLAY_DISMISSED,
                selector="<none>",
                method="escape",
            )
            return await cls._verify_overlay_cleared(page, method="escape")
        except Exception as exc:
            shot_path = await _capture_debug_screenshot(
                page,
                out_dir,
                "debug_overlay_dismiss_failed.png",
            )
            log.warning(
                "ui_automation.overlay_dismiss_failed",
                error=str(exc),
                screenshot=str(shot_path),
                note=(
                    "A blocking overlay was detected but could not be dismissed. "
                    "Manual intervention may be needed."
                ),
            )
            return False

    async def _park_composer_page(self, page: Any, *, event: str) -> None:
        """Park a composer page on about:blank. Best-effort; never raises.

        The pooled page would otherwise stay on ``flow.google.com/project/<id>``:
        the next request on this client would be routed by that URL instead of by
        its own shape (an unmoved account's i2v -> exit 36, or a silently reused
        project), and the next borrower would inherit a mounted composer.
        """
        try:
            await page.goto("about:blank", wait_until="commit", timeout=5_000)
        except Exception as exc:  # noqa: BLE001 - parking is best-effort
            log.warning(event, error=str(exc)[:120])

    async def park_deferred_page(self) -> None:
        """Park a page whose park a FAILED migrated run deferred (#792).

        The park used to sit in a bare ``finally``, so on the failure path it
        navigated to about:blank BEFORE ``FlowApiClient._capture_incident`` staged
        the bundle -- whose own contract is to capture "while the page is still
        alive". Every migrated failure therefore shipped ``tag_counts.div = 0``, a
        white screenshot and ``host_category = "other"`` next to a network journal
        showing the app alive, which is unreadable as evidence.

        Draining it at the START of the next run -- before the route decision reads
        ``page.url`` -- is what makes deferring safe. Doing it at the client's
        failure boundary was not enough: ``generate_images`` is retried inside
        ``post_with_retry`` (``client.py``), so a retryable 5xx never reaches that
        boundary and attempt 2 would re-enter a still-mounted composer. Draining
        here holds the invariant at the only point that consumes it, and resets the
        latch on every path (success, retry, or a later unrelated run).
        """
        if not self._deferred_park_pending:
            return
        self._deferred_park_pending = False
        page = self._page
        if page is not None:
            await self._park_composer_page(page, event="migrated.deferred_page_park_failed")

    async def _settle_if_redirecting(self, page: Any) -> str | None:
        """Settle a navigation only on an account Flow actually redirects (#587).

        No resolved locale means the bootstrap probe saw Flow serve the bare URL
        without redirecting, so there is nothing to wait for and
        :func:`await_url_settled` would burn its full timeout on EVERY navigation.
        Four call sites need this; guarding only the editor entry left the others
        paying 4 s each.
        """
        if self._account_locale is None:
            return None
        return await await_url_settled(page)

    async def _enter_editor(
        self,
        page: Page,
        out_dir: Path | None = None,
        *,
        project_id: str | None = None,
        project_name: str | None = None,
    ) -> None:
        """Create a fresh project OR navigate to an existing one.

        If ``project_id`` is provided, navigates directly to that project's
        editor URL. Otherwise clicks "+ New project" on the gallery and
        waits for ``/project/`` navigation.

        When creating a new project and the URL already contains
        ``/project/`` (Flow's PWA restored the previous project on browser
        launch), this navigates back to the gallery first, then falls
        through to the "+ New project" click — the alternative (returning
        early) would reuse the restored project and accumulate images
        across CLI invocations.
        """
        from gflow_cli.api import routes

        if project_id:
            # #580: the ACCOUNT's locale, resolved from where Flow landed at
            # bootstrap — never a hardcoded default. None omits the segment.
            url = routes.project_editor_url(self._account_locale, project_id)
            log.info("ui_automation.entering_existing_project", project_id=project_id, url=url)
            await page.goto(url, wait_until="domcontentloaded", timeout=45_000)
            # #580: settle BEFORE any DOM work. Logging the before/after pair is
            # how a residual redirect stays visible in the field — and it is the
            # signal the e2e gate asserts on.
            # Only wait when this account is actually redirected. The bootstrap
            # probe already settled that question: no resolved locale means Flow
            # served the bare URL without redirecting, so there is nothing to wait
            # for and the wait would be pure dead time on EVERY navigation.
            before = page.url
            settled = await self._settle_if_redirecting(page)
            if settled and settled != before:
                log.warning(
                    "ui_automation.url_redirected_after_goto",
                    requested=url,
                    was=before,
                    now=settled,
                )
            else:
                log.info(
                    "ui_automation.url_stable_after_goto",
                    url=settled or before,
                    settle_skipped=self._account_locale is None,
                )
            await self._dismiss_blocking_overlays(page, out_dir)
            await self._require_unblocked(page, out_dir, epoch="project editor")
            return

        if _PROJECT_URL_FRAGMENT in page.url:
            # Flow's PWA restores the last-visited project URL on next browser
            # launch (persistent context). Returning early here would reuse the
            # old project, accumulating images across CLI invocations instead of
            # starting fresh. Navigate back to the gallery first, then fall
            # through to the "+ New project" click below.
            # Do NOT use wait_until="networkidle" — PWAs re-render incrementally
            # and networkidle is flaky. The selector wait_for below is the real
            # readiness gate.
            log.info("ui_automation.navigating_to_gallery", restored_url=page.url)
            await page.goto(FLOW_URL, timeout=45_000)
            # #584: FLOW_URL is the bare form, which Flow redirects to the
            # account's locale AFTER goto returns. `_bypass_onboarding` clicks
            # real buttons — running it mid-redirect clicks a page that is
            # leaving. The wait_for_timeout below would absorb it, but it comes
            # after this call, not before.
            await self._settle_if_redirecting(page)
            await self._bypass_onboarding(page)

        await page.wait_for_timeout(3000)
        # #593: this branch reached the "+ New project" sweep with no overlay check at
        # all — the one navigation epoch that had none. An announcement modal here
        # costs 18 selectors x Playwright's 30 s default click timeout and then
        # reports "Could not find 'New project' CTA", which is the wrong error about
        # the wrong thing. Dismiss BEFORE `_bypass_onboarding`, which force-clicks and
        # would otherwise dispatch straight into the overlay.
        await self._dismiss_blocking_overlays(page, out_dir)
        await self._bypass_onboarding(page)
        # AFTER onboarding, not before: consent/CMP dialogs block the body too, and
        # `_bypass_onboarding` is what clears those. Gating first would abort a fresh
        # profile with "dismiss the announcement" when the real blocker is a cookie
        # banner that the very next line would have accepted.
        await self._require_unblocked(page, out_dir, epoch="gallery")
        for selector in NEW_PROJECT_SELECTORS:
            try:
                loc = page.locator(selector).first
                await loc.wait_for(state="visible", timeout=5000)
                log.info("ui_automation.clicking_new_project", selector=selector)
                # Explicit timeout: a covered-but-visible CTA passes the wait above and
                # then blocks on the default 30 s, inside `except: continue`. The
                # element is already known visible, so 5 s is generous for a real click
                # and bounds the sweep at seconds instead of minutes.
                await loc.click(timeout=5000)
                try:
                    await page.wait_for_url(
                        lambda url: _PROJECT_URL_FRAGMENT in url,
                        timeout=15_000,
                    )
                    log.info("ui_automation.entered_editor", url=page.url)
                    return
                except Exception:
                    log.warning(
                        "ui_automation.new_project_click_did_not_navigate",
                        selector=selector,
                    )
            except Exception:
                continue

        # Before blaming the anchor, ask the prior question: is this the gallery at all?
        # NextAuth mounts Flow's OAuth routes on labs.google itself, so a signed-out
        # session sits at `/fx/api/auth/signin?error=Callback` and passes every host
        # check this file makes — `auth/internal_chromium.py` has known that since #767;
        # no transport could see it. The 2026-09-10 RED canary is this exact page,
        # reported as a missing CTA. Consulted only HERE, after the sweep has already
        # run: an early bail would delete the DOM evidence that corrects a wrong
        # absence claim, which is how #739 shipped one (see the note below).
        await raise_if_known_landing(page, requested="the Flow gallery", at="labs.enter_editor")

        shot_path = await _capture_debug_screenshot(page, out_dir, "debug_new_project.png")
        # NO migrated-host branch here. #739 added one asserting that
        # flow.google.com "renders no '+ New project' control gflow can drive". That was an
        # UNPROVEN NEGATIVE, generalised from a sweep of two other surfaces, and a live run
        # disproved it in one click: the CTA is there, carries the `add` ligature, and the
        # Tier-1 entry above now matches it. Reaching this line on a migrated host means the
        # anchor missed — which is selector drift, exactly what the message says.
        msg = (
            f"Could not find 'New project' CTA on Flow gallery. "
            f"URL: {page.url}.{screenshot_clause(shot_path)}"
        )
        raise RuntimeError(
            msg,
        )

    @staticmethod
    async def _switch_to_image_mode(page: Page, *, out_dir: Path | None = None) -> None:
        """Open the 2-step mode dropdown and switch to Image mode.

        Mirror of :meth:`VideoGenerationMixin._switch_to_video_mode`.  Without
        this, an account whose last-used Flow mode was Video silently routes
        ``image t2i`` / ``image batch`` prompts to the video endpoint — no
        ``batchGenerateImages`` response is observed, and the listener times
        out after 3 minutes (an image typically completes in ~15 s).

        The dropdown is closed afterwards (via :kbd:`Escape`) so the caller's
        :meth:`_configure_generation_settings` can open it fresh.
        """
        # New Flow UI: if the composer is in Agent mode the generation panel is
        # absent — switch back to media mode first so the trigger probe below
        # can find the crop_* dropdown.
        await VideoGenerationMixin._exit_agent_mode(page, out_dir=out_dir)
        trigger = await VideoGenerationMixin._probe_selector_cascade(
            page,
            "mode_switch_trigger",
            MODE_SWITCH_TRIGGER_SELECTORS,
        )
        if trigger is None:
            # Reached on the labs arm when --project was supplied: `_enter_editor` returns
            # early there with no readiness gate, so the guard in its gallery arm never
            # ran. Consulted here, where the caller is already about to raise, and BEFORE
            # `_mode_switch_error` classifies -- that helper would otherwise answer
            # "migrated host" or "selector drift" for an account that simply has no Flow.
            await raise_if_known_landing(
                page, requested="the Flow editor", at="labs.switch_to_image_mode"
            )
            raise await VideoGenerationMixin._mode_switch_error(page, out_dir, media="image")
        await trigger.click()
        await page.wait_for_timeout(_jitter_ms(800))
        image_tab = await VideoGenerationMixin._probe_selector_cascade(
            page,
            "image_mode_tab",
            IMAGE_TAB_IN_MENU_SELECTORS,
        )
        if image_tab is None:
            shot = await _capture_debug_screenshot(page, out_dir, "debug_no_image_tab.png")
            raise UiSelectorDriftError(
                selector_drift_detail(
                    "image_mode_tab",
                    "Image tab not found in the mode dropdown.",
                    shot,
                )
            )
        await image_tab.click()
        await page.wait_for_timeout(_jitter_ms(1200))
        await page.keyboard.press("Escape")
        await page.wait_for_timeout(_jitter_ms(200))
        log.info("ui_automation.image_mode_entered")

    # ------------------------------------------------------------------
    # Internal helpers — prompt submission (unit 3.5)
    # ------------------------------------------------------------------

    async def _locate_prompt_box(
        self,
        page: Page,
        out_dir: Path | None = None,
    ) -> Any:
        """Locate the visible Slate prompt box via :data:`PROMPT_INPUT_SELECTORS`.

        Returns the first visible locator (``.first`` of the matching
        selector). On no-match, writes a debug screenshot to ``out_dir``
        (if provided) and raises ``RuntimeError``.
        """
        for selector in PROMPT_INPUT_SELECTORS:
            try:
                loc = page.locator(selector).first
                await loc.wait_for(state="visible", timeout=10_000)
                log.info("ui_automation.prompt_input_found", selector=selector)
                return loc
            except Exception:
                continue

        # The third site, and the worst of the three. `_enter_editor(project_id=...)`
        # has no readiness gate of its own — it navigates, settles, checks overlays and
        # returns — so a landing page passes all of it and the FIRST thing to fail is
        # this sweep. It raises a bare RuntimeError, which `observability.py` SHA-256
        # hashes because it is not a GFlowError, so the operator is shown "Unexpected
        # error" with even the URL destroyed. Worse than the drift report #756 is about.
        await raise_if_known_landing(page, requested="the Flow editor", at="labs.locate_prompt_box")

        shot_path = await _capture_debug_screenshot(page, out_dir, "debug_prompt_not_found.png")
        msg = f"Prompt input not found in Flow UI. URL: {page.url}.{screenshot_clause(shot_path)}"
        raise RuntimeError(msg)

    async def _click_submit(self, page: Page) -> None:
        """Submit the active prompt via the ``arrow_forward`` button.

        Tries :data:`SUBMIT_BUTTON_SELECTORS` in priority order; falls back
        to pressing Enter if no submit button is visible.
        """
        for sel in SUBMIT_BUTTON_SELECTORS:
            try:
                btn = page.locator(sel).first
                await btn.wait_for(state="visible", timeout=2_000)
                await btn.click()
                log.info("ui_automation.prompt_submitted", via=sel)
                return
            except Exception:
                continue

        log.info("ui_automation.prompt_submitted", via="enter_key_fallback")
        await page.keyboard.press("Enter")

    async def format_character_prompt(
        self,
        page: Page,
        *,
        prompt_box: Any,
        typed_text: str,
    ) -> bool:
        """Click Flow's Format button and WAIT for the rewrite to actually land.

        Best-effort, like :meth:`_select_character_model`: formatting is a nicety
        on top of a prompt that already submits fine, so every failure logs and
        returns ``False`` rather than failing the generation. Callers submit
        regardless — which is why the return value must not lie.

        **Returning ``True`` means the composer's text changed, not that a button
        was pressed.** Flow rewrites *server-side*: measured 2026-09-07 on the
        migrated host, the click fires a ``batchexecute`` round trip and the
        reshaped text reaches the composer at **~5.4 s**, while this method used to
        wait ``_jitter_ms(500)`` and return. ``_send_prompt`` submits on the very
        next line, so ``--format-prompt`` shipped the prompt the user typed and
        discarded the rewrite — on every run, with ``prompt_formatted`` logged and
        exit 0. The defect was never the duration. It was reporting a success we
        had not observed: the absence of a completion inside a window we chose,
        recorded as a completion. See
        ``docs/superpowers/spikes/2026-09-07-format-click-is-not-a-format.md``.

        The gate is the DOM, not the wire. ``eAenfb``'s response arrives **4.2 s
        before** the text settles, so awaiting it would reproduce the same early
        submit — and an undocumented ``batchexecute`` rpcid is not an anchor this
        project is willing to depend on. Comparing the box against the string we
        inserted is locale-invariant by construction: it never reads a display label.

        A **length delta** rather than ``!=`` because Slate/ProseMirror re-render
        and normalise whitespace; bare inequality would fire on that churn and
        re-report the same false success with better telemetry.

        The enabled check is NOT redundant with the visible check. Flow ships this
        button ``disabled`` while the prompt box is empty (verified 2026-07-27), and
        a disabled button is still *visible* — so visibility alone would hand a
        disabled element to ``click()``, which auto-waits for actionability and
        stalls for the full timeout. A disabled match means THAT anchor resolved to
        the wrong element, so the cascade continues rather than aborting: the old
        ``return False`` here let one stale anchor kill every selector behind it.
        """
        button = await self._locate_format_button(page, prompt_box=prompt_box)
        if button is None:
            log.warning("ui_automation.format_button_not_found", selectors=PROMPT_FORMAT_SELECTORS)
            return False

        locator, selector = button
        try:
            # Explicit short timeout: never inherit Playwright's 30s default on
            # a best-effort nicety sitting in front of the submit.
            await locator.click(timeout=5000)
        except Exception as e:
            log.warning("ui_automation.format_click_failed", selector=selector, error=str(e))
            return False
        log.info("ui_automation.format_button_clicked", selector=selector)

        typed = typed_text.strip()
        deadline = time.monotonic() + _FORMAT_REWRITE_TIMEOUT_S
        started = time.monotonic()
        while time.monotonic() < deadline:
            await page.wait_for_timeout(_jitter_ms(_FORMAT_REWRITE_POLL_MS))
            try:
                current = (await prompt_box.inner_text()).strip()
            except Exception as e:
                log.debug("ui_automation.format_readback_failed", error=str(e))
                continue
            # GROWTH, not absolute delta. `abs()` accepted change in either direction, and
            # Flow CLEARS the box before repopulating it — so a poll landing in that window
            # read "" and `abs(0 - 19) >= 16` passed. `prompt_formatted` then logged
            # `prompt_len_after=0` and `_click_submit` ran on the next line, submitting an
            # EMPTY prompt on a path that spends image quota (#745). A success signal that
            # fires on the ABSENCE of the thing it measures is the defect #727 was about,
            # rebuilt inside its own fix.
            if len(current) < len(typed) + _FORMAT_REWRITE_MIN_DELTA or current == typed:
                continue
            # And confirm it settled. One read can land mid-write; the rewrite observed live
            # was a single discrete swap, but that was sampled at 250ms and a partial write
            # between samples was never ruled out. Two agreeing reads cost one interval.
            await page.wait_for_timeout(_jitter_ms(_FORMAT_REWRITE_POLL_MS))
            try:
                settled = (await prompt_box.inner_text()).strip()
            except Exception as e:
                log.debug("ui_automation.format_readback_failed", error=str(e))
                continue
            if settled != current:
                log.debug("ui_automation.format_still_settling", chars=len(settled))
                continue
            # Lengths and a stable hash only. Flow ELABORATES a terse description into a
            # detailed physical one, so the rewrite is more PII-dense than the input, and
            # structlog is not governed by GFLOW_CLI_HISTORY_PROMPTS — no operator control
            # would apply to it.
            log.info(
                "ui_automation.prompt_formatted",
                selector=selector,
                elapsed_ms=int((time.monotonic() - started) * 1000),
                prompt_len_before=len(typed),
                prompt_len_after=len(current),
                prompt_hash=_prompt_hash_stable(current),
            )
            return True

        # Say what was observed, never what Flow "failed" to do: an unchanged box
        # also covers Flow declining, erroring, or judging the prompt already
        # formatted. None of those were provoked (2026-09-07), so none are claimed.
        log.warning(
            "ui_automation.format_not_observed",
            selector=selector,
            waited_s=_FORMAT_REWRITE_TIMEOUT_S,
            prompt_len=len(typed),
        )
        return False

    async def _locate_format_button(self, page: Page, *, prompt_box: Any) -> Any:
        """Resolve the Format button belonging to the ACTIVE composer.

        Returns ``(locator, selector)`` or ``None``.

        Box identity matters here. :meth:`_locate_body_prompt_box` documents that
        on a two-box cohort "the LAST mounted box is the target" — the body
        composer, never the portrait's. A page-global ``.first`` on the format
        button therefore resolves to the PORTRAIT composer's button while the body
        prompt is the one that was just typed into, reshaping the wrong prompt (or
        finding a disabled button and giving up). This mirrors that existing
        convention rather than inventing a second one: when more than one prompt
        box is mounted, take the last matching button.
        """
        try:
            boxes = await page.locator(self._CHARACTER_EDITOR_READY_SELECTOR).count()
        except Exception:
            boxes = 1
        for selector in PROMPT_FORMAT_SELECTORS:
            try:
                matches = page.locator(selector)
                locator = matches.last if boxes > 1 else matches.first
                # No timeout argument: Playwright documents it as ignored here —
                # `is_visible()` never waits, it answers from the current DOM, so a
                # non-matching entry costs one round trip rather than a second.
                if not await locator.is_visible():
                    continue
                if not await locator.is_enabled():
                    log.debug("ui_automation.format_button_disabled", selector=selector)
                    continue
                return (locator, selector)
            except Exception as e:
                log.debug("ui_automation.format_selector_failed", selector=selector, error=str(e))
        return None

    async def _send_prompt(
        self,
        page: Page,
        prompt_text: str,
        out_dir: Path | None = None,
        format_prompt: bool = False,
    ) -> None:
        """Type ``prompt_text`` into Flow's editor and submit.

        Selectors are tried in priority order; the first visible match
        wins. The text input is cleared first (Slate.js requires real
        keyboard events — ``.fill()`` bypasses onChange handlers).

        A staged R2V character entity is NOT affected by the clear: 'Incluir no
        comando' stages it in a separate references drawer, not as a chip inside
        this prompt box (verified 2026-06-06), so the entity still rides the
        submit.

        Submission is preferred via the Create button; if no submit
        button is visible, Enter is pressed as a fallback.

        On input-not-found, a debug screenshot is written to ``out_dir``
        (if provided) and ``RuntimeError`` is raised.
        """
        # Dismiss any overlays that might have appeared since entering the editor.
        await self._dismiss_blocking_overlays(page, out_dir)

        input_box = await self._locate_prompt_box(page, out_dir)

        await input_box.click()
        await page.keyboard.press("Control+A")
        await page.keyboard.press("Delete")
        # insert_text fires a single beforeinput event that Slate.js handles
        # natively — near-instant vs keyboard.type() which is ~1.5s/char.
        await page.keyboard.insert_text(prompt_text)
        await page.wait_for_timeout(_jitter_ms(500))

        if format_prompt:
            # The bound box and the exact string we inserted — the rewrite is only
            # detectable against a baseline we know landed, and holding that baseline
            # on `self` would couple it across generations on a reused page.
            await self.format_character_prompt(page, prompt_box=input_box, typed_text=prompt_text)

        await self._click_submit(page)

    async def _submit_body_prompt(
        self,
        page: Page,
        body_description: str,
        *,
        boxes_before: int,
        shared_body_box: bool = False,
        out_dir: Path | None = None,
        format_prompt: bool = False,
    ) -> None:
        """Submit a self-contained triptych body prompt into the body slot's OWN box.

        Activating Create Body auto-attaches the generated face as a reference.
        Current Flow reuses the existing Slate box; legacy cohorts mount a new
        one. Rather than parsing either cohort's localized placeholder/template,
        this helper replaces the settled body composer with gflow's own
        locale-independent triptych instruction plus the body description.

        :meth:`_locate_body_prompt_box` binds the shared box only after the face
        reference mounts, or the legacy last box only after its count rises.
        Observed live 2026-07-25 (0.43.0, incident 8ecd11cc): typing before the
        mode settled replaced the stored portrait prompt, which Flow autosaved.

        Before any destructive keyboard input, the helper verifies that the
        selected body box retained focus. After typing,
        :meth:`_verify_body_prompt_isolation` verifies the target and, when the
        legacy portrait box is separately mounted, reads that box back too.

        ONE generation then yields all three angles (front/side/back) as a
        single triptych image, seeded by the auto-attached face reference.

        Logs ``ui_automation.body_prompt_templated`` with ``template`` and the
        submitted length (NO body text).
        """
        input_box = await self._locate_body_prompt_box(
            page,
            boxes_before=boxes_before,
            shared_body_box=shared_body_box,
            out_dir=out_dir,
        )

        full_prompt = _BODY_TRIPTYCH_PREAMBLE + body_description

        # Clear Flow's pre-filled (localized) template and replace it wholesale.
        # Slate.js needs real keyboard events, but every event must stay bound to
        # this locator: page-global keyboard calls can follow a late focus bounce
        # into the autosaved portrait composer.
        await input_box.click()
        await self._verify_body_prompt_focus(page, input_box, out_dir)
        await input_box.press("Control+A")
        await input_box.press("Delete")
        await input_box.press_sequentially(full_prompt)
        await page.wait_for_timeout(_jitter_ms(500))

        # Readback guard — abort BEFORE submit if the typing landed in the
        # portrait box (mode switch not settled → the 2026-07-25 corruption).
        await self._verify_body_prompt_isolation(page, input_box, out_dir)

        log.info(
            "ui_automation.body_prompt_templated",
            template="self_contained",
            prompt_len=len(full_prompt),
        )
        if format_prompt:
            # `input_box` is the BODY composer, bound by _locate_body_prompt_box —
            # passing it is what keeps the format click off the portrait's box on a
            # two-box cohort.
            await self.format_character_prompt(page, prompt_box=input_box, typed_text=full_prompt)

        await self._click_submit(page)

    async def _count_character_prompt_boxes(self, page: Page) -> int:
        """Count the editor's prompt boxes (legacy body-mode baseline).

        Counts through the SAME anchor the readiness gate accepts, so both
        frontends are seen: labs mounts Slate, flow.google.com mounts
        ProseMirror. Counting only Slate reported 0 boxes on the migrated host
        and aborted the body step with "Body prompt box did not mount" — on an
        editor whose box was mounted and visible the whole time (2026-09-06).
        """
        return int(await page.locator(self._CHARACTER_EDITOR_READY_SELECTOR).count())

    async def _locate_body_prompt_box(
        self,
        page: Page,
        *,
        boxes_before: int,
        shared_body_box: bool = False,
        out_dir: Path | None = None,
    ) -> Any:
        """Locate the body composer's OWN Slate prompt box — never the portrait's.

        The character editor is a two-mode surface (Portrait / Create Body).
        Typing before the switch settles can overwrite the stored portrait
        prompt (observed live 2026-07-25, incident 8ecd11cc), so localized mode
        labels are never treated as proof of the active composer.

        The current editor (live 2026-07-26) reuses one Slate box and signals a
        settled body mode by mounting the generated-face reference; callers
        pass ``shared_body_box=True`` only after observing that signal. Older
        cohorts mount a second box, so their count must exceed
        ``boxes_before``. In either case the LAST mounted box is the target.
        """
        # Both frontends' anchors — see _count_character_prompt_boxes.
        loc = page.locator(self._CHARACTER_EDITOR_READY_SELECTOR)
        deadline = time.monotonic() + _BODY_SLOT_MOUNT_TIMEOUT_S
        count = int(await loc.count())
        required_count = 0 if shared_body_box else boxes_before
        while count <= required_count and time.monotonic() < deadline:
            await page.wait_for_timeout(_BODY_SLOT_MOUNT_POLL_MS)
            count = int(await loc.count())
        if count <= required_count:
            shot = await _capture_debug_screenshot(
                page, out_dir, "debug_body_prompt_box_not_mounted.png"
            )
            settle_signal = (
                "the shared body-mode box disappeared"
                if shared_body_box
                else "no additional body box mounted"
            )
            msg = (
                f"Body prompt box did not mount within "
                f"{_BODY_SLOT_MOUNT_TIMEOUT_S:.0f}s after body-mode activation "
                f"(prompt boxes: {count}, before slot-add: {boxes_before}). "
                f"The body-mode settle check reported that {settle_signal}. "
                "Typing now would land in the portrait prompt box and "
                "overwrite the stored portrait prompt — aborting the body "
                f"step. URL: {page.url}.{screenshot_clause(shot)}"
            )
            raise RuntimeError(msg)
        box = loc.nth(count - 1)
        await box.wait_for(state="visible", timeout=10_000)
        log.info(
            "ui_automation.body_prompt_box_bound",
            boxes_before=boxes_before,
            boxes_now=count,
        )
        return box

    async def _verify_body_prompt_focus(
        self,
        page: Page,
        input_box: Any,
        out_dir: Path | None = None,
    ) -> None:
        """Fail closed unless the body box owns focus before destructive input."""
        try:
            focused = bool(
                await input_box.evaluate(
                    "element => element === document.activeElement "
                    "|| element.contains(document.activeElement)"
                )
            )
        except Exception as e:
            shot = await _capture_debug_screenshot(
                page, out_dir, "debug_body_prompt_focus_unverified.png"
            )
            msg = (
                "Could not verify body prompt focus before editing; aborting to preserve "
                "the stored portrait prompt. "
                f"URL: {page.url}.{screenshot_clause(shot)}"
            )
            raise RuntimeError(msg) from e
        if not focused:
            shot = await _capture_debug_screenshot(
                page, out_dir, "debug_body_prompt_wrong_focus.png"
            )
            msg = (
                "Body composer focus moved to the wrong prompt box before editing. "
                "Aborting before destructive input so the stored portrait prompt is "
                f"not overwritten. URL: {page.url}.{screenshot_clause(shot)}"
            )
            raise RuntimeError(msg)

    async def _verify_body_prompt_isolation(
        self,
        page: Page,
        input_box: Any,
        out_dir: Path | None = None,
    ) -> None:
        """Post-type readback: the triptych text is in the body box ONLY.

        A wrong-box landing (the portrait composer captured the typing while
        the Create-Body mode switch was still settling) corrupts the entity's
        stored portrait prompt — Flow autosaves the box via
        PATCH /v1/flowWorkflows/{id} (observed live 2026-07-25, 0.43.0).
        Abort BEFORE submit in that case. Readback I/O errors also fail closed:
        unstable prompt state is not safe to submit on an autosaved surface.
        """
        sentinel = _BODY_TRIPTYCH_PREAMBLE[:24]
        try:
            target_text = str(await input_box.inner_text() or "")
            # Readiness anchor, not the Slate-only selector: on the migrated
            # editor the latter counts 0 boxes, so the portrait-overwrite guard
            # below silently compared against an empty string.
            boxes = page.locator(self._CHARACTER_EDITOR_READY_SELECTOR)
            box_count = int(await boxes.count())
            portrait_text = str(await boxes.first.inner_text() or "") if box_count > 1 else ""
        except Exception as e:
            log.warning(
                "ui_automation.body_prompt_readback_failed",
                error=str(e)[:120],
            )
            shot = await _capture_debug_screenshot(
                page, out_dir, "debug_body_prompt_readback_failed.png"
            )
            msg = (
                "Could not verify body prompt isolation after editing. "
                "Aborting before submit because the prompt boxes became unstable. "
                f"URL: {page.url}.{screenshot_clause(shot)}"
            )
            raise RuntimeError(msg) from e
        if sentinel in portrait_text or sentinel not in target_text:
            shot = await _capture_debug_screenshot(page, out_dir, "debug_body_prompt_wrong_box.png")
            msg = (
                "Body triptych prompt landed in the wrong prompt box "
                f"(portrait polluted: {sentinel in portrait_text}, "
                f"body box has prompt: {sentinel in target_text}). "
                "Aborting before submit so a corrupted portrait prompt is "
                "never generated. Re-check the entity's portrait prompt "
                f"in the Flow UI. URL: {page.url}.{screenshot_clause(shot)}"
            )
            raise RuntimeError(msg)

    # ------------------------------------------------------------------
    # Internal helpers — generation settings (aspect ratio + count)
    # ------------------------------------------------------------------

    @staticmethod
    async def _open_gen_settings_panel(page: Page) -> bool:
        """Try selectors in order to open the per-generation settings panel.

        Returns True on success, False if no selector matched (non-fatal —
        caller falls back to Flow's current defaults).
        """
        for sel in GEN_SETTINGS_BUTTON_SELECTORS:
            try:
                btn = page.locator(sel).first
                await btn.wait_for(state="visible", timeout=3_000)
                await btn.click()
                await page.wait_for_timeout(600)
                log.info("ui_automation.gen_settings_opened", via=sel)
                return True
            except Exception:
                continue
        return False

    @staticmethod
    async def _read_displayed_count(page: Page) -> int | None:
        """Read the currently-displayed image count from the settings panel.

        Locale-invariant: filters ``[aria-selected="true"]`` tabs by
        :data:`_COUNT_TAB_TEXT_RE` so only count tabs (both label cohorts,
        e.g. "1x"/"x1", "x2") are considered.  Mode tabs ("image\\nImagem") and Aspect tabs
        ("16:9", etc.) are selected simultaneously in the Radix tablist DOM
        and would poison the old unfiltered ``[aria-selected="true"]`` query.

        Returns the integer count (1–4) extracted from the matched tab's text,
        or ``None`` when no count tab is selected / visible.
        """
        try:
            selected = page.locator('[role="tab"][aria-selected="true"]').filter(
                has_text=_COUNT_TAB_TEXT_RE,
            )
            if await selected.count() == 0:
                return None
            text = (await selected.first.text_content(timeout=500) or "").strip()
            m = re.search(r"\d", text)
            return int(m.group()) if m else None
        except Exception:
            return None

    @staticmethod
    async def _is_settings_panel_open(page: Page) -> bool:
        """True if the generation-settings panel count tabs are currently visible.

        Uses :func:`_count_tabs_locator` — the panel is open when at least one
        count tab (text matching either label cohort, e.g. ``1x``/``x1``,
        ``x2``) is visible.
        This is locale-invariant and immune to Mode/Aspect tab false-positives.
        """
        try:
            return await _count_tabs_locator(page).first.is_visible()
        except Exception:
            return False

    @staticmethod
    async def _select_image_model(page: Page, model: Model) -> None:
        """Click the image model picker and select *model*, or FAIL.

        Must run with the gen-settings panel open.

        Fails loudly by design (changed 2026-08-26). This previously swallowed
        every failure, logged a WARNING, and let the generation proceed on Flow's
        UI-default model — so a stale selector meant the user asked for one model,
        silently received another, and was BILLED for it.

        That was not hypothetical. Flow's picker on 2026-08-26 offers
        ``Nano Banana Pro`` / ``Nano Banana 2`` / ``Nano Banana 2 Lite``;
        ``Model.IMAGEN_3_5``'s ``has-text('Imagen 4')`` matches nothing, and
        ``has-text('Nano Banana 2')`` matches TWO entries.

        AMBIGUOUS is treated as a failure, not a ``.first`` guess: ``.first``
        resolves by DOM order, so an ambiguous selector silently picks whichever
        Flow renders first and changes behaviour with no code change on our side.

        Raises before anything is submitted, so a failure costs nothing.
        """
        option_sels = IMAGE_MODEL_OPTION_SELECTORS.get(model)
        if not option_sels:
            raise UiSelectorDriftError(
                selector_drift_detail(
                    "image_model",
                    f"no picker selector registered for model {model.value!r}.",
                    None,
                )
            )

        trigger = page.locator(IMAGE_MODEL_PICKER_TRIGGER).first
        await trigger.wait_for(state="visible", timeout=4000)
        await trigger.click()
        await page.wait_for_timeout(500)

        offered = await offered_menu_labels(page)
        for sel in option_sels:
            try:
                matches, first_visible = await count_visible(page, sel)
            except Exception as exc:  # noqa: BLE001
                log.debug("ui_automation.image_model_selector_miss", sel=sel, error=str(exc)[:120])
                continue
            if matches == 0:
                continue
            if matches > 1:
                await close_menu(page)
                raise UiSelectorDriftError(
                    selector_drift_detail(
                        "image_model",
                        (
                            f"selector for {model.value!r} is AMBIGUOUS — {matches} entries "
                            f"match {sel!r}. Selecting .first would pick by DOM order and "
                            f"could bill a different model than requested. "
                            f"Flow offered: {offered}."
                        ),
                        None,
                    )
                )
            assert first_visible is not None  # matches > 0 implies one was found
            await first_visible.click()
            await page.wait_for_timeout(500)
            log.info("ui_automation.image_model_selected", model=model.value, via=sel)
            return

        await close_menu(page)
        raise UiSelectorDriftError(
            selector_drift_detail(
                "image_model",
                (
                    f"model {model.value!r} is not selectable — no picker entry matched. "
                    f"Flow offered: {offered}. Refusing to generate on a different model "
                    f"than requested."
                ),
                None,
            )
        )

    @staticmethod
    async def _configure_generation_settings(
        page: Page,
        aspect_cli: str | None,
        count: int | None,
        *,
        model: Model | None = None,
        out_dir: Path | None = None,
        prompt_idx: int | None = None,
    ) -> None:
        """Open the per-generation settings panel and apply model, aspect ratio,
        and count.

        When ``out_dir`` and ``prompt_idx`` are both provided, diagnostic
        screenshots are saved as ``count_before_prompt_{idx}.png`` and
        ``count_after_prompt_{idx}.png`` so future count-drift can be
        diagnosed without re-instrumenting the code.

        Skips gracefully if the panel trigger cannot be found (non-fatal —
        generation will proceed with Flow's current default settings).
        """
        if aspect_cli is None and count is None and model is None:
            # Nothing to apply.
            return

        # Phase 3 — before screenshot (diagnostic, best-effort).
        await UiAutomationTransport._capture_diag_screenshot(
            page,
            out_dir,
            prompt_idx,
            "before",
        )

        if not await UiAutomationTransport._open_gen_settings_panel(page):
            # A requested MODEL cannot be honoured without this panel, and the
            # submit will inherit whatever the project's picker holds — the
            # silent wrong-model path (#586).
            #
            # This deliberately WARNS rather than raises. An earlier version
            # raised here; the existing batch tests showed it turning one
            # transient panel miss on prompt 0 into a whole-batch abort, because
            # the transport cannot distinguish "user passed --model X" from
            # "X is the default" — `request.model` is populated either way, so a
            # raise punishes callers who never asked for a specific model.
            #
            # Detection moved to where it is arm-agnostic and costs nothing:
            # `services.catalog_sync.parse_media_attribution` reads what the
            # SERVER says generated each media. That catches this on the agentic
            # arm too, where this code path never runs at all.
            if model is not None:
                log.warning(
                    "ui_automation.image_model_not_applied",
                    model=model.value,
                    reason="generation-settings panel could not be opened",
                    note="generation will use the project's current selection",
                )
            log.warning("ui_automation.gen_settings_panel_not_found", skipping=True)
            return

        if model is not None:
            await UiAutomationTransport._select_image_model(page, model)

        if aspect_cli:
            await UiAutomationTransport._apply_aspect_ratio(page, aspect_cli)

        if count is not None:
            await UiAutomationTransport._apply_count(page, count, out_dir, prompt_idx)

        # Phase 3 — after screenshot (diagnostic, best-effort).
        await UiAutomationTransport._capture_diag_screenshot(
            page,
            out_dir,
            prompt_idx,
            "after",
        )

        await page.keyboard.press("Escape")
        await page.wait_for_timeout(400)

    @staticmethod
    async def _capture_diag_screenshot(
        page: Page,
        out_dir: Path | None,
        prompt_idx: int | None,
        suffix: str,
    ) -> None:
        if out_dir is not None and prompt_idx is not None:
            diag_dir = out_dir / _DIAGNOSTICS_SUBDIR
            diag_dir.mkdir(parents=True, exist_ok=True)
            await _capture_debug_screenshot(
                page,
                diag_dir,
                f"count_{suffix}_prompt_{prompt_idx}.png",
            )

    @staticmethod
    async def _apply_aspect_ratio(page: Page, aspect_cli: str) -> None:
        candidates = _ASPECT_TAB_CANDIDATES.get(aspect_cli, (aspect_cli,))
        clicked = False
        last_err: str | None = None
        for tab_text in candidates:
            # `:text-is(...)` is exact-match — preferred for short labels
            # like "1:1" because `:has-text(...)` substring-matches and
            # would clash with longer tabs that include the label.
            try:
                tab = page.locator(f'[role="tab"]:text-is("{tab_text}")').first
                await tab.wait_for(state="visible", timeout=2_000)
                await tab.click()
                clicked = True
                log.info(
                    "ui_automation.aspect_ratio_set",
                    value=aspect_cli,
                    matched_label=tab_text,
                )
                break
            except Exception as e:
                last_err = str(e)
                continue
        if not clicked:
            log.warning(
                "ui_automation.aspect_ratio_set_failed",
                value=aspect_cli,
                candidates_tried=list(candidates),
                error=last_err,
            )

    @staticmethod
    async def _apply_count(
        page: Page,
        count: int,
        out_dir: Path | None,
        prompt_idx: int | None,
    ) -> None:
        if count not in _SUPPORTED_COUNTS:
            log.warning("ui_automation.unsupported_count", value=count)
        else:
            await UiAutomationTransport._set_count(
                page,
                count,
                out_dir=out_dir,
                prompt_idx=prompt_idx,
            )

    @staticmethod
    async def _dump_count_panel_dom(
        page: Page,
        out_dir: Path | None,
        prompt_idx: int | None,
    ) -> None:
        """Diagnostic dump of the count-tab area of the editor to out_dir.

        Writes a JSON file enumerating candidate structural patterns so we can
        derive locale-invariant selectors from real DOM evidence (per issue #24).

        Captures:
          - All elements with role="tab", role="tablist", role="radiogroup",
            role="radio" — count, aria-label, aria-selected, text content.
          - All buttons inside any visible Material panel — text, aria-label,
            leading digit if any, google-symbols icon ligature children.
          - Document title + page URL for context.

        Safe-by-default: no-op if out_dir is None or prompt_idx is None.
        Failures swallowed (this is diagnostic).
        """
        if out_dir is None or prompt_idx is None:
            return
        try:
            snapshot = await page.evaluate("""() => {
                const result = {
                    url: location.href,
                    title: document.title,
                    roles: {},
                    buttons_with_digits: [],
                    google_symbols_ligatures: [],
                };
                for (const role of ['tab', 'tablist', 'radiogroup', 'radio']) {
                    const els = Array.from(document.querySelectorAll('[role="' + role + '"]'));
                    result.roles[role] = els.map(el => ({
                        text: (el.innerText || '').slice(0, 120),
                        aria_label: el.getAttribute('aria-label'),
                        aria_selected: el.getAttribute('aria-selected'),
                        aria_controls: el.getAttribute('aria-controls'),
                        id: el.id || null,
                        classes: el.className.toString().slice(0, 200),
                    }));
                }
                // Buttons whose visible text starts with a digit (count-tab candidates).
                for (const btn of document.querySelectorAll('button')) {
                    const text = (btn.innerText || '').trim();
                    if (/^\\d/.test(text)) {
                        result.buttons_with_digits.push({
                            text: text.slice(0, 120),
                            aria_label: btn.getAttribute('aria-label'),
                            aria_selected: btn.getAttribute('aria-selected'),
                            role: btn.getAttribute('role'),
                            parent_role: btn.parentElement?.getAttribute('role') || null,
                            parent_class: (btn.parentElement?.className
                                ?.toString().slice(0, 200)) || null,
                        });
                    }
                }
                // Google Symbols icons present anywhere — gives us the ligature names Flow uses.
                // Class-only, NOT tag-qualified. This query used to read
                // 'i.google-symbols, span.google-symbols' and therefore returned ZERO on the
                // migrated host, where every ligature rides a <mat-icon>. The instrument we
                // reach for to diagnose selector drift was blind to the host the drift lives
                // on — which is why #727 and #731 stayed invisible, and why an incident
                // bundle from a migrated user reported no ligatures at all (#730).
                const _gsQuery = '.google-symbols';
                for (const el of document.querySelectorAll(_gsQuery)) {
                    const lig = (el.innerText || '').trim();
                    if (lig) result.google_symbols_ligatures.push({
                        ligature: lig,
                        parent_text: (el.parentElement?.innerText || '').trim().slice(0, 80),
                        parent_role: el.parentElement?.getAttribute('role'),
                        parent_aria_label: el.parentElement?.getAttribute('aria-label'),
                    });
                }
                return result;
            }""")
            diag_dir = out_dir / _DIAGNOSTICS_SUBDIR
            diag_dir.mkdir(parents=True, exist_ok=True)
            target = diag_dir / f"count_panel_dom_prompt_{prompt_idx}.json"
            target.write_text(json.dumps(snapshot, indent=2, ensure_ascii=False), encoding="utf-8")
            log.info(
                "ui_automation.count_panel_dom_dumped",
                target=str(target),
                tabs_count=len(snapshot.get("roles", {}).get("tab", [])),
                digit_buttons_count=len(snapshot.get("buttons_with_digits", [])),
                ligatures_count=len(snapshot.get("google_symbols_ligatures", [])),
            )
        except Exception as exc:
            log.warning(
                "ui_automation.count_panel_dom_dump_failed",
                error=str(exc),
                prompt_idx=prompt_idx,
            )

    @staticmethod
    async def _set_count(
        page: Page,
        count: int,
        *,
        out_dir: Path | None = None,
        prompt_idx: int | None = None,
    ) -> None:
        """Click the count tab by its DIGIT — locale-invariant, read-back verify with retry.

        Algorithm (#404 rewrite of the #24 positional pick):
        1. Ensure the settings panel is open without toggling it closed
           (stay-mounted batch: panel may already be open from the prior prompt).
        2. Read the currently-displayed count via :data:`_COUNT_TAB_TEXT_RE` —
           immune to Mode/Aspect tabs, matches both label cohorts.
        3. If it already matches ``count``, return early (no click needed).
        4. Click the tab selected by :func:`_count_tab_locator_for` — keyed on
           the digit in the label (``1x``/``x1`` for count=1), NOT position:
           Flow's label rename shrank the old filtered set and shifted every
           positional pick by one (issue #404).
        5. Read back the digit and confirm the change.
        6. Retry up to 3 attempts total; raise :class:`UiSelectorDriftError`
           (exit 23) on non-convergence — a bare ``RuntimeError`` would be
           message-hashed by observability into an opaque ``UnexpectedError``.

        When read-back returns ``None`` (no selected count tab recognised),
        the digit-keyed click is trusted — it is deterministic regardless.

        Four structlog events are emitted for diagnosability:
        - ``ui_automation.count_setter_entered``
        - ``ui_automation.count_click_attempted``
        - ``ui_automation.count_click_result``
        - ``ui_automation.count_setter_completed``
        """
        panel_open = await UiAutomationTransport._is_settings_panel_open(page)
        initial_displayed = await UiAutomationTransport._read_displayed_count(page)

        log.info(
            "ui_automation.count_setter_entered",
            desired_count=count,
            panel_currently_visible=panel_open,
            initial_displayed_count=initial_displayed,
        )

        # Ensure the panel is open — open it only if it's currently closed
        # (avoid toggling a stay-mounted open panel closed).
        if not panel_open:
            opened = await UiAutomationTransport._open_gen_settings_panel(page)
            if not opened:
                log.warning(
                    "ui_automation.count_setter_panel_open_failed",
                    desired_count=count,
                )
                # Non-fatal: completed event records failure.
                log.info(
                    _EVT_COUNT_SETTER_COMPLETED,
                    desired_count=count,
                    final_displayed_count=initial_displayed,
                    success=False,
                    attempts=0,
                )
                return

        # Diagnostic DOM dump — captured after panel is confirmed open, before any
        # tab click attempt. Produces count_panel_dom_prompt_{idx}.json in out_dir
        # so the real DOM structure is visible for selector research (issue #24).
        await UiAutomationTransport._dump_count_panel_dom(page, out_dir, prompt_idx)

        _max_attempts = 3
        # Reuse the initial read — avoids a redundant DOM round-trip.
        displayed: int | None = initial_displayed

        for attempt in range(1, _max_attempts + 1):
            # If current display already matches desired, we're done.
            if displayed == count:
                log.info(
                    _EVT_COUNT_SETTER_COMPLETED,
                    desired_count=count,
                    final_displayed_count=displayed,
                    success=True,
                    attempts=attempt - 1,
                )
                return

            panel_visible_before = await UiAutomationTransport._is_settings_panel_open(page)
            clicked = False
            click_error: str | None = None

            # Digit-keyed pick: the tab whose label carries the desired digit
            # ("1x"/"x1" for count=1). Position-independent — survives the
            # label-cohort rename and filtered-set drift (issue #404).
            target_tab = _count_tab_locator_for(page, count).first
            selector_desc = f"count-tab label ~ /^({count}x|x{count})$/"
            log.info(
                "ui_automation.count_click_attempted",
                target=f"count={count}",
                selector=selector_desc,
                panel_visible=panel_visible_before,
                current_displayed_count=displayed,
            )
            try:
                await target_tab.wait_for(state="visible", timeout=3_000)
                await target_tab.click()
                await page.wait_for_timeout(300)
                clicked = True
            except Exception as e:
                click_error = str(e)

            # Read back to verify (digit-extraction, locale-agnostic).
            displayed = await UiAutomationTransport._read_displayed_count(page)
            log.info(
                "ui_automation.count_click_result",
                target=f"count={count}",
                success=clicked,
                effect_observed=displayed == count,
                current_displayed_count_after=displayed,
                error=click_error,
            )

            # Success when the click landed AND read-back digit matches, OR
            # when read-back returned None (no selected count tab recognised —
            # the digit-keyed click targeted the right tab, so trust it).
            if clicked and (displayed is None or displayed == count):
                log.info(
                    _EVT_COUNT_SETTER_COMPLETED,
                    desired_count=count,
                    final_displayed_count=displayed,
                    success=True,
                    attempts=attempt,
                    readback_trusted=(displayed is None),
                )
                return

            # Brief pause before retry to allow React re-render.
            if attempt < _max_attempts:
                await page.wait_for_timeout(500)

        # All attempts exhausted without convergence.
        log.info(
            _EVT_COUNT_SETTER_COMPLETED,
            desired_count=count,
            final_displayed_count=displayed,
            success=False,
            attempts=_max_attempts,
        )
        shot = await _capture_debug_screenshot(page, out_dir, "debug_count_setter_drift.png")
        raise UiSelectorDriftError(
            selector_drift_detail(
                "count_tab",
                f"count setter failed to converge: desired={count}, "
                f"displayed={displayed} after {_max_attempts} attempts. "
                f"Flow's count control may have changed again "
                f"(labels are matched as {count}x/x{count}).",
                shot,
            )
        )

    # ------------------------------------------------------------------
    # Internal helpers — batchGenerateImages capture (unit 3.6)
    # ------------------------------------------------------------------

    @staticmethod
    def _attach_batch_response_listener(
        page: Page,
        *,
        project_id: str | None = None,
    ) -> tuple[list[dict[str, Any]], Callable[[], None]]:
        """Synchronously register a ``page.on('response', ...)`` listener
        that records ``batchGenerateImages`` responses into a shared list.

        When ``project_id`` is provided, only responses whose URL contains
        ``/projects/{project_id}/`` are captured — this prevents stale
        responses from previously-visited projects accumulating in the list.

        Returns ``(captured, detach_fn)``:
        - ``captured`` is the shared list — the caller submits the prompt
          next, then polls / awaits that list via :meth:`_await_captured`.
        - ``detach_fn`` removes the handler from the page when called; it is
          idempotent (safe to call multiple times).

        Registering the listener BEFORE issuing the prompt click eliminates
        the race where the click could fire before an ``asyncio.create_task``-
        scheduled listener attaches.
        """
        captured: list[dict[str, Any]] = []

        async def on_response(response: Any) -> None:
            if "batchGenerateImages" not in response.url:
                return
            # Log EVERY batchGenerateImages response BEFORE the project_id
            # filter so live verification can diagnose listener-miss bugs
            # (e.g., URL contains a different project_id than the editor URL).
            log.info(
                "ui_automation.batch_response_seen",
                url=response.url,
                status=response.status,
                filter_project_id=project_id,
            )
            if project_id and f"/projects/{project_id}/" not in response.url:
                log.warning(
                    "ui_automation.batch_response_dropped_project_id_mismatch",
                    url=response.url,
                    filter_project_id=project_id,
                )
                return
            try:
                body = await response.json()
            except Exception as e:
                log.warning(
                    "ui_automation.batch_response_parse_failed",
                    error=str(e),
                    url=response.url,
                )
                return
            headers: dict[str, str] = {}
            raw_hdrs: Any = getattr(response, "headers", None)
            if raw_hdrs is not None:
                try:
                    if callable(raw_hdrs):
                        raw_hdrs = raw_hdrs()
                    if isinstance(raw_hdrs, dict):
                        raw_dict: dict[Any, Any] = cast("dict[Any, Any]", raw_hdrs)
                        headers = {str(k): str(v) for k, v in raw_dict.items()}
                except Exception:
                    pass
            captured.append(
                {
                    "status": response.status,
                    "url": response.url,
                    "body": body,
                    "headers": headers,
                    "ts": time.monotonic(),
                },
            )
            log.info(
                "ui_automation.batch_response_captured",
                status=response.status,
                url=response.url,
            )

        page.on("response", on_response)

        _detached = False

        def detach() -> None:
            nonlocal _detached
            if _detached:
                return
            _detached = True
            try:
                page.remove_listener("response", on_response)
            except Exception:
                pass

        return captured, detach

    @staticmethod
    def _attach_batch_request_logger(
        page: Page,
        *,
        project_id: str | None = None,
        sink: list[dict[str, Any]] | None = None,
        record_generation_request: GenerationRequestRecorder | None = None,
    ) -> Callable[[], None]:
        """Register a ``page.on('request', ...)`` that logs a compact summary of
        each outgoing ``batchGenerateImages`` body.

        The summary (see :func:`_summarize_batch_request_body`) surfaces whether
        the submit carries ``referenceEntities`` — the entity-reference spike's
        make-or-break signal — without dumping i2i image bytes. Returns an
        idempotent detach fn, torn down alongside the response listener.

        When *sink* is given, each matching request also appends
        ``{"url", "entity_ids"}`` so the caller can enforce the #170 submit
        backstop (:meth:`_assert_image_entities_attached`) after the run.
        """

        def on_request(request_obj: Any) -> None:
            if "batchGenerateImages" not in request_obj.url:
                return
            try:
                post_data = request_obj.post_data
            except Exception:
                post_data = None
            log.info(
                "ui_automation.batch_request_body",
                url=request_obj.url,
                filter_project_id=project_id,
                summary=_summarize_batch_request_body(post_data),
            )
            entity_ids = _entity_ids_from_request_body(post_data)
            if sink is not None:
                sink.append({"url": request_obj.url, "entity_ids": entity_ids})
            # #528: persist a counts-only echo into the incident bundle. The
            # stderr log above is richer but evaporates; the bundle is what a
            # reporter actually attaches to an issue.
            if record_generation_request is not None:
                try:
                    record_generation_request(
                        url=request_obj.url,
                        body_bytes=len(post_data or ""),
                        reference_entity_count=len(entity_ids),
                        reference_field_count=_reference_field_count(post_data),
                        mentions_reference_entities="referenceEntit" in (post_data or ""),
                    )
                except Exception:  # noqa: BLE001, S110 — observation only, never break a submit
                    pass

        page.on("request", on_request)

        _detached = False

        def detach() -> None:
            nonlocal _detached
            if _detached:
                return
            _detached = True
            try:
                page.remove_listener("request", on_request)
            except Exception:
                pass

        return detach

    @staticmethod
    async def _await_captured(
        captured: list[dict[str, Any]],
        timeout_s: float = 180.0,
        *,
        expected_count: int = 1,
        submit_time: float = 0.0,
        poll_interval_s: float = 0.5,
        straggler_window_s: float = 2.5,
    ) -> list[dict[str, Any]]:
        """Wait for ``expected_count`` batchGenerateImages responses.

        Flow generates N images via N separate API calls (not one call with
        N URLs). We poll until we have enough fresh responses (those whose
        ``ts >= submit_time``) or the timeout expires.

        **Defense A — post-submit-time filter (primary correctness fix):**
        Each captured entry carries a ``ts`` field written by the handler at
        append time (``time.monotonic()``). Only entries with
        ``entry["ts"] >= submit_time`` count toward ``expected_count``.  This
        eliminates the cross-contamination bug where a listener attached
        *before* the submit click inherits stale responses from prior prompts
        that arrived in the window between attach and click.

        When ``submit_time`` is 0.0 (the default, used by
        ``_capture_batch_response`` and legacy callers), all entries pass the
        filter, preserving backwards compatibility.

        **Straggler window:** after the count threshold is first reached the
        method waits an additional ``straggler_window_s`` seconds so that any
        slower same-submission responses (e.g. the last of a 2-image batch)
        can arrive before the list is snapshotted. This mirrors the Worker
        pattern (``_wait_for_n_new_images`` in the compile-growth monorepo).

        Raises ``TimeoutError`` if no fresh responses arrive within
        ``timeout_s``.  Returns the underlying response dicts (entries without
        the ``ts`` wrapper key) for entries with ``ts >= submit_time``.
        """
        deadline = time.monotonic() + timeout_s

        def _fresh() -> list[dict[str, Any]]:
            return [e for e in captured if e.get("ts", 0.0) >= submit_time]

        # Poll until we have enough fresh responses or the deadline passes.
        while time.monotonic() < deadline and len(_fresh()) < expected_count:
            await asyncio.sleep(poll_interval_s)

        fresh = _fresh()
        if not fresh:
            msg = f"No batchGenerateImages response within {timeout_s:.1f}s."
            raise TimeoutError(msg)
        if len(fresh) < expected_count:
            log.warning(
                "ui_automation.fewer_responses_than_expected",
                got=len(fresh),
                expected=expected_count,
            )
        else:
            # Threshold reached — wait for any slow stragglers from this same
            # submission before snapshotting the list.
            await asyncio.sleep(straggler_window_s)
            fresh = _fresh()

        # Return entries stripped of the internal `ts` bookkeeping key so
        # callers (_images_from_responses, tests) receive plain response dicts.
        return [{k: v for k, v in e.items() if k != "ts"} for e in fresh]

    @staticmethod
    async def _capture_batch_response(
        page: Page,
        timeout_s: float = 120.0,
        *,
        poll_interval_s: float = 0.5,
    ) -> list[dict[str, Any]]:
        """Convenience wrapper: attach + await in one call.

        Useful when the caller has no work to interleave between attach
        and wait. ``generate_images`` does NOT use this — it splits the
        two halves so the listener is attached synchronously before
        ``_send_prompt`` issues the click.
        """
        captured, _detach = UiAutomationTransport._attach_batch_response_listener(page)
        return await UiAutomationTransport._await_captured(
            captured,
            timeout_s,
            poll_interval_s=poll_interval_s,
        )

    # ------------------------------------------------------------------
    # Internal helpers — image download (unit 3.8)
    # ------------------------------------------------------------------

    @staticmethod
    async def _download(
        urls: list[str],
        out_dir: Path,
        cookies: dict[str, str],
    ) -> list[Path]:
        """Download each URL into ``out_dir`` using session cookies.

        Saves to ``out_dir / image_NN.png`` (zero-padded index). Individual
        download failures are logged and skipped — the function returns the
        list of paths that DID write successfully.

        URLs whose host is not in :data:`_ALLOWED_DOWNLOAD_HOST_SUFFIXES`
        are skipped before any HTTP request is made — this prevents
        session cookies from being forwarded to a non-Google host through
        a malicious or compromised fifeUrl. Redirects are also disabled
        (``follow_redirects=False``) so an open-redirect on an allowed
        host cannot rebound the request to a third party.
        """
        import httpx  # local import — httpx is a runtime dependency

        out_dir.mkdir(parents=True, exist_ok=True)
        paths: list[Path] = []
        async with httpx.AsyncClient(
            timeout=30.0,
            follow_redirects=False,
            cookies=cookies,
        ) as client:
            for i, url in enumerate(urls):
                if not _is_allowed_download_host(url):
                    log.error(
                        "ui_automation.download_host_rejected",
                        url=url,
                        allowed_suffixes=list(_ALLOWED_DOWNLOAD_HOST_SUFFIXES),
                    )
                    continue
                try:
                    resp = await client.get(url)
                    resp.raise_for_status()
                    # Auto-detect extension from Content-Type / magic bytes.
                    ct = resp.headers.get("content-type", "")
                    if "jpeg" in ct or "jpg" in ct or resp.content[:3] == b"\xff\xd8\xff":
                        ext = ".jpg"
                    else:
                        ext = ".png"
                    p = out_dir / f"image_{i:02d}{ext}"
                    p.write_bytes(resp.content)
                    paths.append(p)
                    log.info(
                        "ui_automation.image_saved",
                        path=str(p),
                        bytes=len(resp.content),
                        format=ext,
                    )
                except Exception as e:
                    log.exception(
                        "ui_automation.download_failed",
                        url=url,
                        error=str(e),
                    )
        return paths

    # ------------------------------------------------------------------
    # Protocol — generate_images (unit 3.9)
    # ------------------------------------------------------------------

    async def generate_images(
        self,
        *,
        project_id: str | None,
        request: GenerateImageRequest,
        name_resolver: Callable[[str], str | None] | None = None,
    ) -> list[GeneratedImage]:
        """Submit ``request.prompt`` through Flow's editor and return the
        generated images as DTOs.

        If ``project_id`` is provided, navigates to that project. Otherwise
        creates a new one.

        Raises ``RuntimeError`` if setup() has not been called, the
        ``batchGenerateImages`` response is non-200, or the response is
        200 but contains no image URLs.
        """
        if not self._setup_done or self._page is None:
            msg = "UiAutomationTransport.setup() must be called before generate_images()"
            raise RuntimeError(
                msg,
            )
        async with self._generate_lock:
            return await self._generate_images_locked(
                request, project_id=project_id, name_resolver=name_resolver
            )

    async def upload_reference(self, *, project_id: str, path: Path) -> ImageRef | None:
        """Upload ``path`` into the project on flow.google.com and return its handle.

        ``None`` when this page routes to the labs driver: the client then uses the REST
        upload. On flow.google.com the composer toolbar uploads it and names the media id
        and the run-unique caption it was listed under, which is everything a later
        in-place mention needs (#913). Serialized with generation, parked after use.
        """
        if not self._setup_done or self._page is None:
            msg = "UiAutomationTransport.setup() must be called before upload_reference()"
            raise RuntimeError(msg)
        from gflow_cli.api.transports.migrated_composer import MigratedComposer  # noqa: PLC0415
        from gflow_cli.config import get_settings  # noqa: PLC0415

        async with self._generate_lock:
            page: Page = self._page
            await self.park_deferred_page()
            route = migrated_route(page.url, get_settings().flow_host, prefer_migrated=True)
            if route == "labs":
                return None
            if route == "blocked":
                raise_if_migrated(page, at="reference_upload_kill_switch")
            composer = MigratedComposer(out_dir=self._out_dir)
            try:
                await composer.ensure_editor(page, project_id)
                media_id, display_name = await composer.upload(page, project_id, path)
            except Exception:
                # Same failure discipline as image generation (#792): keep the page for
                # the incident bundle; the next run drains the park.
                self._deferred_park_pending = True
                raise
            await self._park_composer_page(page, event="migrated.upload_page_park_failed")
            log.info("migrated.reference_uploaded", media_id=media_id)
            return ImageRef(name=media_id, display_name=display_name, in_project=True)

    def uses_page_owned_image_recaptcha(self) -> bool:
        """This transport drives Flow's own page, which mints its own reCAPTCHA token on
        click -- nothing here ever reads ``request.recaptcha_token`` (#891). The client
        uses the capability to skip its pre-mint. Narrow optional capability rather than
        a Protocol member: only UI automation owns a page."""
        return True

    async def _generate_images_locked(
        self,
        request: GenerateImageRequest,
        *,
        project_id: str | None = None,
        name_resolver: Callable[[str], str | None] | None = None,
    ) -> list[GeneratedImage]:
        """Serialized body of generate_images — called under self._generate_lock."""
        from gflow_cli.api.transports.drivers.factory import (  # noqa: PLC0415
            get_ui_driver,
        )

        page: Page = self._page  # type: ignore[assignment]  # guard in caller
        out_dir = self._out_dir

        from gflow_cli.api.transports.migrated_composer import run_images  # noqa: PLC0415
        from gflow_cli.config import get_settings  # noqa: PLC0415

        # #792: a FAILED migrated run leaves this page on the project URL on
        # purpose, so the incident bundle is captured from a live page instead of
        # about:blank. Drain that deferred park HERE — before the route decision
        # reads page.url, and before anything re-enters a still-mounted composer.
        # This is also the retry path: generate_images runs inside
        # post_with_retry, so a retryable 5xx never reaches the client's failure
        # boundary and attempt 2 would otherwise resume on a dirty composer.
        await self.park_deferred_page()
        flow_host = get_settings().flow_host
        prefer = migrated_images_prefer(request, page_url=page.url, project_id=project_id)
        route = migrated_route(page.url, flow_host, prefer_migrated=prefer)
        if route == "labs":
            await self._enter_editor(page, out_dir, project_id=project_id)
            # Dismiss any Flow changelog / "What's new" overlay that may be on top
            # of the editor before we click into settings / submit (#26).
            await self._dismiss_blocking_overlays(page, out_dir)
            prefer = migrated_images_prefer(request, page_url=page.url, project_id=project_id)
            route = migrated_route(page.url, flow_host, prefer_migrated=prefer)
        if route == "blocked":
            raise_if_migrated(page, at="image_flow_host_kill_switch")
        if route == "migrated":
            try:
                result = await run_images(page, request, project_id=project_id, out_dir=out_dir)
            except Exception:
                # #792: do NOT park here. FlowApiClient stages the incident bundle
                # from THIS page at its failure boundary, and parking first hands
                # the triager about:blank. `park_deferred_page` runs it after.
                self._deferred_park_pending = True
                raise
            except BaseException:
                # Cancellation/KeyboardInterrupt: no bundle is staged for these, so
                # nothing is waiting on the page. Attempt the park inline -- but a
                # re-delivered cancel can pre-empt it at the `goto` await, and
                # `except Exception` cannot catch that. The next run's drain is the
                # guarantee; this is the courtesy.
                self._deferred_park_pending = True
                await self._park_composer_page(page, event="migrated.image_page_park_failed")
                raise
            # Park off the project so the next borrower of this page does not
            # inherit a mounted composer (on the FAILURE path this is deferred to
            # the next run -- see park_deferred_page, #792).
            await self._park_composer_page(page, event="migrated.image_page_park_failed")
            return result

        # Determine the arm this command REQUIRES: explicit --ui-mode / env, or
        # inferred — agent instructions (-i) are an agentic-only surface, so they
        # force agentic. get_ui_driver switches to the required arm as a
        # PREREQUISITE, VERIFIES via a DOM re-probe, and fails fast
        # (UiModeUnavailableError, exit 28) if the arm is unreachable — so -i can
        # never silently no-op on a classic bind, and no credits are spent. The
        # cohort flaps per page load, so this runs every generation (no caching).
        from gflow_cli.config import infer_required_ui_mode, resolve_ui_mode

        base_mode = request.ui_mode if request.ui_mode is not None else resolve_ui_mode(None)
        required_mode = infer_required_ui_mode(
            base_mode, has_instructions=bool(request.instructions)
        )
        # Inject ``self`` into the classic driver at construction (via the
        # factory) — never mutate ``_transport`` onto the driver after the fact.
        ui_driver = await get_ui_driver(page, ui_mode=required_mode, transport=self)

        # Select Image mode explicitly. If the account was last in Video mode,
        # an unguarded submission goes to the video endpoint and the image
        # listener never observes ``batchGenerateImages``.
        await ui_driver.switch_to_image_mode(page, out_dir=out_dir)

        # Resolve the project_id from the URL now that we're in the editor.
        nav_project_id = _extract_project_id(page.url)

        # Configure generation settings (aspect ratio + count) BEFORE attaching
        # the response listener so settings clicks don't interfere with capture.
        await ui_driver.configure_image_settings(
            page,
            request,
            out_dir=out_dir,
        )

        # I2I: bind local reference images through the editor's media dialog —
        # the same add_2 dialog as video R2V, via the inherited _attach_references.
        # The REST uploadImage path 401s, and passive capture needs the refs IN
        # the UI (not just a wire body), so we attach + let Flow's JS include them.
        if request.ref_paths:
            # prefer_existing: dedup a repeated local ref by selecting the
            # already-uploaded library asset (named by its filename) instead of
            # re-uploading it (#314). Image i2i only; R2V keeps upload-every-time.
            await self._attach_references(
                page, list(request.ref_paths), out_dir=out_dir, prefer_existing=True
            )

        # Pre-generated image UUID refs: attach by selecting the EXISTING Flow
        # asset in the reference picker (no duplicate upload — founder principle),
        # falling back to uploading the local file only when it can't be located.
        if request.refs:
            await self._attach_image_uuid_refs(
                page,
                [(r.name, r.display_name, r.local_path, r.local_sha256) for r in request.refs],
                out_dir=out_dir,
                name_resolver=name_resolver,
            )

        # Entity references: attach locked CHARACTER entities via the Personagens
        # picker (inherited from the video transport). The entity must live in the
        # project we generate in (pass --project / project_id). Flow's JS then
        # includes them on the submit; the request logger below records whether the
        # outgoing batchGenerateImages carries `referenceEntities` (spike signal).
        if len(request.reference_entity_names) > len(request.reference_entities):
            # A character resolved by name only (#723: the character catalog failed) has
            # no id, and this picker attaches by id — refuse rather than drop it.
            raise MentionIndexUnavailableError(detail="the character source is unavailable")
        if request.reference_entities:
            await self._attach_character_entities(
                page,
                zip_entity_refs(request.reference_entities, request.reference_entity_names),
                out_dir=out_dir,
            )

        # Wrap generation submission in the reference entities interceptor context.
        # This programmatically filters outgoing batchGenerateImages requests so that
        # only the explicitly requested reference_entities are permitted to go to the server,
        # preventing stale or poisoned entities from smuggling themselves into unrelated runs.
        expected_ents = set(request.reference_entities)
        async with self._intercept_reference_entities(page, expected_ents):
            # Agentic path: DOM scraping (page-level network capture is dead in this
            # cohort — requests are Web-Worker-delegated, so 0 entries are captured).
            # The request + expected count are handed to the driver directly.
            from gflow_cli.api.transports.drivers.agentic import (  # noqa: PLC0415
                AgenticFlowUiDriver,
            )

            if isinstance(ui_driver, AgenticFlowUiDriver):
                return await ui_driver.submit_images(page, request, request.count, out_dir=out_dir)

            # Classic path: network-capture via response listener (unchanged).
            # Attach the response listener SYNCHRONOUSLY before any prompt
            # action. asyncio.create_task is unsafe here: it defers the listener
            # registration until the new task gets event-loop scheduling, which
            # could happen AFTER _send_prompt's click on a busy loop. Splitting
            # attach/await eliminates that race. Project-ID filter prevents stale
            # responses from previously-visited projects accumulating in the list.
            captured, detach = self._attach_batch_response_listener(page, project_id=nav_project_id)
            # Also log the OUTGOING request body summary AND collect the entity ids
            # it carries — the #170 submit backstop reads the sink after the run.
            request_bodies: list[dict[str, Any]] = []
            req_log_detach = self._attach_batch_request_logger(
                page,
                project_id=nav_project_id,
                sink=request_bodies,
                record_generation_request=self._record_generation_request,
            )
            # Record submit_time BEFORE the click so the post-submit-time filter
            # in _await_captured can distinguish this prompt's responses from any
            # stale entries that arrived between listener attach and the click.
            submit_time = time.monotonic()
            responses: list[dict[str, Any]] = []
            try:
                await ui_driver.send_prompt(page, request.prompt, out_dir=out_dir)
                responses = await self._await_captured(
                    captured,
                    expected_count=request.count,
                    submit_time=submit_time,
                )
            finally:
                detach()
                req_log_detach()

        # Collect images from ALL captured responses (Flow makes one API call
        # per image when count > 1).
        images, first_error_status, first_error_route, first_error_body = _images_from_responses(
            responses
        )

        if first_error_status is not None and not images:
            # #528: a 400 here is a content-policy rejection, not a wire problem.
            raise generation_error(
                status=first_error_status,
                route=first_error_route,
                body=first_error_body,
            )

        if not images:
            raise ContentPolicyError(
                detail="batchGenerateImages returned 200 but no parseable media items",
                route=first_error_route or "",
            )
        # Submit backstop (issue #170): the run is only a success if every
        # requested character entity actually rode the wire. A missed UI attach
        # (e.g. the include selector clicked the wrong element) would otherwise
        # return a plain text-only generation as if it used the character.
        if request.reference_entities:
            self._assert_image_entities_attached(
                request_bodies, expected=list(request.reference_entities)
            )
        return images

    @staticmethod
    def _assert_image_entities_attached(
        request_bodies: list[dict[str, Any]],
        *,
        expected: list[str],
    ) -> None:
        """Defense-in-depth mirror of the video path's _assert_entities_attached.

        *request_bodies* is the sink filled by :meth:`_attach_batch_request_logger`
        (one entry per captured outgoing ``batchGenerateImages`` body). Every
        *expected* entity id must appear in at least one captured submit;
        otherwise raise :class:`WireFormatError` — never report a text-only
        generation as an entity-referenced success.
        """
        seen: set[str] = set()
        for body in request_bodies:
            ids = body.get("entity_ids")
            if isinstance(ids, set):
                seen |= cast("set[str]", ids)
        missing = [e for e in expected if e not in seen]
        if missing:
            raise WireFormatError(
                detail=(
                    f"captured batchGenerateImages submit is missing "
                    f"referenceEntities {missing} — the staged character "
                    f"never rode the wire"
                ),
                route="flowMedia:batchGenerateImages",
                remediation_hint=ENTITY_ATTACH_DRIFT_HINT,
                discovery={"entity_attach_context": "image"},
            )
        log.info("ui_automation.image_entities_attached", entity_ids=sorted(seen))

    # ------------------------------------------------------------------
    # Public batch API — generate_images_batch (stay-mounted, v3-3)
    # ------------------------------------------------------------------

    async def generate_images_batch(
        self,
        *,
        prompts: list[GenerateImageRequest],
        jitter_range: tuple[float, float],
        continue_on_error: bool = False,
    ) -> list[BatchSubmissionResult]:
        """Submit all prompts into one Flow project and return per-prompt results.

        Opens the editor once, configures+submits each prompt with jitter
        between submissions, awaits and parses responses in submission order.
        The editor stays mounted for the full batch lifetime — this is the
        bug fix for --same-project=1 no-op (each call to generate_images
        previously created a new project and discarded the caller's project_id).

        With ``continue_on_error=False`` (default): the first per-prompt
        failure stops further submissions, remaining listeners are detached,
        and ``BatchPartialError`` is raised carrying any already-completed
        ``BatchSubmissionResult`` records so the orchestrator can salvage
        paid-for images before re-raising.

        With ``continue_on_error=True``: all prompts are submitted regardless
        of per-prompt failures; failed prompts produce results with
        ``status="fail"`` and a non-None ``error`` field.
        """
        if not self._setup_done or self._page is None:
            msg = "UiAutomationTransport.setup() must be called before generate_images_batch()"
            raise RuntimeError(
                msg,
            )
        # The batch path drives labs selectors only — `run_images` is the single-image
        # port. Without this it ran those selectors against flow.google.com and failed
        # as selector drift (exit 23), blaming a frontend that was fine. Refuse before
        # any submit so the user gets the non-retryable exit 36 and the real reason.
        raise_if_migrated(self._page, at="image_batch_unported")
        async with self._generate_lock:
            return await self._generate_images_batch_locked(
                prompts=prompts,
                jitter_range=jitter_range,
                continue_on_error=continue_on_error,
            )

    async def _run_one_prompt_in_batch(
        self,
        *,
        page: Page,
        idx: int,
        req: GenerateImageRequest,
        project_id: str,
        out_dir: Path | None,
        ui_driver: Any,
    ) -> tuple[BatchSubmissionResult, GFlowError | None]:
        """Single prompt's lifecycle inside a batch: configure → attach
        listener → submit → await → detach → parse.

        Returns ``(result, fatal_error)``.  ``fatal_error`` is ``None`` on
        success or whenever the failure was non-fatal (the caller can
        continue).  When non-``None`` it carries the :class:`GFlowError`
        the caller should propagate via :class:`BatchPartialError`.  Detach
        is guaranteed exactly once on every code path.
        """
        prompt_hash = _prompt_hash_stable(req.prompt)

        def _fail(exc: BaseException) -> tuple[BatchSubmissionResult, GFlowError]:
            g_exc = (
                exc
                if isinstance(exc, GFlowError)
                else GFlowError(detail=str(exc), route="generate_images_batch")
            )
            return (
                BatchSubmissionResult(
                    status="fail",
                    project_id=project_id,
                    prompt_idx=idx,
                    prompt_hash=prompt_hash,
                    images=(),
                    error=g_exc,
                ),
                g_exc,
            )

        # Step 1 — configure settings (aspect + count) for this prompt.
        #
        # #593 gap audit: this is an overlay epoch, and it was the last unguarded
        # one. A batch dismisses overlays ONCE during setup; from prompt 2 on,
        # these settings clicks are the first act after `_await_captured` — a
        # multi-second generation wait on a page that never navigates, so neither
        # the navigation gate nor `_probe_selector_cascade` covers them. And the
        # failure here is silent, not loud: `_open_gen_settings_panel` returns
        # False when nothing matches and the caller falls back to Flow's current
        # defaults, so a modal that mounted during prompt 1 does not fail prompt 2
        # — it generates it at the wrong aspect/count. One probe on the happy path.
        try:
            await self._require_unblocked(page, out_dir, epoch=f"batch prompt {idx}")
            await ui_driver.configure_image_settings(
                page,
                req,
                out_dir=out_dir,
                prompt_idx=idx,
            )
        except Exception as exc:
            return _fail(exc)

        # Agentic path: DOM scraping — no page-level listener (Web-Worker-delegated).
        from gflow_cli.api.transports.drivers.agentic import (  # noqa: PLC0415
            AgenticFlowUiDriver,
        )

        if isinstance(ui_driver, AgenticFlowUiDriver):
            try:
                images = await ui_driver.submit_images(page, req, req.count, out_dir=out_dir)
            except Exception as exc:
                return _fail(exc)
            return (
                BatchSubmissionResult(
                    status="ok",
                    project_id=project_id,
                    prompt_idx=idx,
                    prompt_hash=prompt_hash,
                    images=tuple(images),
                    error=None,
                ),
                None,
            )

        # Classic path: network-capture via response listener (unchanged).
        # Step 2 — attach a fresh listener JUST for this prompt.
        # Attaching after configure ensures settings-panel clicks never land
        # in the listener window.  Detach happens immediately after
        # _await_captured returns so no two listeners are ever live at once.
        captured, detach = self._attach_batch_response_listener(page, project_id=project_id)
        # Record submit_time BEFORE the click — defense-in-depth: the
        # post-submit-time filter in _await_captured rejects any stale
        # entries that slipped into the freshly-attached listener before
        # the click fired.
        submit_time = time.monotonic()

        # Step 3 — submit the prompt.
        try:
            await ui_driver.send_prompt(page, req.prompt, out_dir=out_dir)
        except Exception as exc:
            detach()
            return _fail(exc)

        # Step 4 — await THIS prompt's responses, then detach immediately.
        try:
            responses = await self._await_captured(
                captured,
                expected_count=req.count,
                submit_time=submit_time,
            )
        except Exception as exc:
            detach()
            return _fail(exc)
        detach()

        # Step 5 — parse responses.
        if len(responses) < req.count:
            err = GFlowError(
                detail=f"_await_captured timed out: got {len(responses)}/{req.count}",
                route="generate_images_batch",
            )
            return (
                BatchSubmissionResult(
                    status="fail",
                    project_id=project_id,
                    prompt_idx=idx,
                    prompt_hash=prompt_hash,
                    images=(),
                    error=err,
                ),
                err,
            )

        images, first_error_status, first_error_route, first_error_body = _images_from_responses(
            responses
        )
        if not images:
            # #528: classify rather than hand back a bare GFlowError with no
            # remediation — a policy 400 here needs the same guidance the
            # single-prompt path gets.
            err = (
                generation_error(
                    status=first_error_status,
                    route=first_error_route or "generate_images_batch",
                    body=first_error_body,
                )
                if first_error_status is not None
                else GFlowError(
                    detail="no parseable images (every response was 200 with no media)",
                    route="generate_images_batch",
                )
            )
            return (
                BatchSubmissionResult(
                    status="fail",
                    project_id=project_id,
                    prompt_idx=idx,
                    prompt_hash=prompt_hash,
                    images=(),
                    error=err,
                ),
                err,
            )

        return (
            BatchSubmissionResult(
                status="ok",
                project_id=project_id,
                prompt_idx=idx,
                prompt_hash=prompt_hash,
                images=tuple(images),
                error=None,
            ),
            None,
        )

    async def _generate_images_batch_locked(
        self,
        *,
        prompts: list[GenerateImageRequest],
        jitter_range: tuple[float, float],
        continue_on_error: bool,
    ) -> list[BatchSubmissionResult]:
        """Serialized body of generate_images_batch — called under self._generate_lock.

        Strictly serial submission (Worker pattern): each prompt's full
        lifecycle (configure → attach → submit → await → detach → parse)
        completes before the next prompt's listener is attached.  Only one
        listener is active at a time, making cross-contamination structurally
        impossible even when Flow's response payload carries no per-submission
        identifier.

        The editor stays mounted for the full batch (same-project invariant
        intact) — only the submit/await cycle is serial.
        """
        from gflow_cli.api.transports.drivers.factory import (  # noqa: PLC0415
            get_ui_driver,
        )

        page: Any = self._page  # type: ignore[assignment]
        out_dir = self._out_dir

        # ---- Batch-setup phase (once per batch) ----
        await self._enter_editor(page, out_dir)
        project_id = _extract_project_id(page.url)
        if project_id is None:
            msg = (
                f"Could not extract project_id from editor URL after _enter_editor. URL: {page.url}"
            )
            raise RuntimeError(
                msg,
            )

        try:
            await self._dismiss_blocking_overlays(page, out_dir)
        except Exception:
            # Orphaned-project warning: _enter_editor succeeded (server-side project
            # was created) but a later setup step failed. Log so the user can find
            # their orphaned project on the Flow UI.
            log.warning(
                "ui_automation.orphaned_project_warning",
                project_id=project_id,
                page_url=page.url,
                failed_step="_dismiss_blocking_overlays",
            )
            raise

        # Probe the DOM for the active UI cohort AFTER _enter_editor.  The
        # cohort flaps per page load; bind once per batch (the editor stays
        # mounted so the cohort is stable for this batch's lifetime).
        # Classic driver requires a transport reference for send_prompt.
        # The image-batch manifest carries no per-item -i instructions
        # (single-prompt only), so ``has_instructions`` is fixed False — but the
        # call still routes through infer_required_ui_mode so batch inherits the
        # same policy as the single path (#595: auto ≡ classic). It had its own
        # inline resolve_ui_mode and so kept binding AUTO after the single path
        # stopped. Pass instructions through here if batch ever gains them.
        from gflow_cli.config import infer_required_ui_mode, resolve_ui_mode

        required_mode = infer_required_ui_mode(resolve_ui_mode(None), has_instructions=False)
        # Inject ``self`` into the classic driver at construction (via the
        # factory) — never mutate ``_transport`` onto the driver after the fact.
        ui_driver = await get_ui_driver(page, ui_mode=required_mode, transport=self)

        try:
            await ui_driver.switch_to_image_mode(page, out_dir=out_dir)
        except Exception:
            log.warning(
                "ui_automation.orphaned_project_warning",
                project_id=project_id,
                page_url=page.url,
                failed_step="_switch_to_image_mode",
            )
            raise

        # ---- Serial per-prompt cycle: each prompt's lifecycle (configure →
        # attach → submit → await → detach → parse) is encapsulated in
        # ``_run_one_prompt_in_batch``.  This outer loop only manages
        # iteration, result collection, fail-fast control, and inter-prompt
        # jitter.
        results: list[BatchSubmissionResult] = []
        submit_error: GFlowError | None = None

        for idx, req in enumerate(prompts):
            result, fatal_err = await self._run_one_prompt_in_batch(
                page=page,
                idx=idx,
                req=req,
                project_id=project_id,
                out_dir=out_dir,
                ui_driver=ui_driver,
            )
            results.append(result)

            # Fail-fast: break before the next submission so we do not spend
            # credits on prompts the caller will not see in the success path.
            if result.status == "fail" and not continue_on_error and fatal_err is not None:
                submit_error = fatal_err
                break

            # Jitter between iterations (anti-bot cadence) — not after the last.
            if idx < len(prompts) - 1:
                await asyncio.sleep(random.uniform(*jitter_range))

        # Fail-fast: surface partial-results salvage so orchestrator can download
        # already-paid-for images before re-raising.
        if submit_error is not None and not continue_on_error:
            raise BatchPartialError(
                detail=f"batch failed at prompt index {len(results)}: {submit_error!s}",
                route="generate_images_batch",
                partial_results=tuple(r for r in results if r.status == "ok"),
                cause=submit_error,
            )

        return results

    # ------------------------------------------------------------------
    # Character editor — navigation + passive-capture entry (T4)
    # ------------------------------------------------------------------

    # Selector for the character editor's Slate prompt textbox — used as the
    # "editor mounted" readiness anchor.  Its first alternative IS
    # PROMPT_INPUT_SELECTORS[0];
    # duplicated here as a named constant so the character-editor path is
    # self-documenting without importing the tuple.
    # Two frontends, one feature. labs.google renders the character editor with
    # React + Slate; flow.google.com renders the SAME editor — same tRPC backend,
    # same aisandbox REST, same entities — with Angular + ProseMirror (recon
    # 2026-09-06, scripts/dev/spike_migrated_character_editor_anchor.py). Asking
    # only for Slate made a present feature look absent for 20 s and then get
    # reported as "labs-only, ever", which was wrong. Both anchors are library
    # build artefacts rather than display strings, so neither translates.
    _CHARACTER_EDITOR_READY_SELECTOR = (
        'div[role="textbox"][data-slate-editor="true"], div.ProseMirror[contenteditable="true"]'
    )

    # Slot-add button for character image slots 1+ (body / accessories).
    #
    # Live DOM evidence (2026-06-02 spike, character editor with slot 0 filled)
    # disproved the old ``button:has(...).nth(1)`` heuristic.  Two ``add_2``
    # ligatures exist in the editor DOM and they are STRUCTURALLY DISTINCT:
    #
    #   1. Slot-add (the target):  ``<div role="button"
    #      aria-label="Adicionar imagem do personagem"><i ...>add_2</i></div>``
    #      — a ``[role=button]`` div whose ONLY accessible content is the
    #      ``add_2`` icon (icon-only; no visible/sibling text-label span).
    #   2. The decoy:  ``<button type="button" aria-haspopup="dialog">
    #      <i ...>add_2</i><span style="...clip...">…</span></button>`` — a real
    #      ``<button>`` carrying a sibling ``<span>`` text label.
    #
    # The old ``button:has(i.google-symbols:text('add_2'))`` selector did not
    # even MATCH the slot-add (it is a ``div[role=button]``, not ``<button>``);
    # ``.nth(1)`` of that locator landed on the wrong control entirely.
    #
    # Robust, language-agnostic discriminator: the slot-add is the ``add_2``
    # icon hosted in a ``[role=button]`` whose stripped ``inner_text`` is EXACTLY
    # the ligature ``"add_2"`` (icon-only).  The decoy's hidden label makes its
    # inner_text longer, so it is excluded.  The localised aria-label
    # ("Adicionar imagem do personagem") is NEVER the primary anchor — see
    # [[flow-locale-leak-icon-ligatures]] — it may only serve as a positional
    # hint.  ``text-is`` (exact match) is used so partial-ligature collisions
    # (e.g. ``add_2_box``) cannot match.
    #: Both ligature carriers: labs uses `<i class="google-symbols">`, the migrated
    #: Angular frontend uses `<mat-icon>`. Anchoring on one host's carrier is what
    #: made the whole character surface look absent on the other (2026-09-06).
    _CHARACTER_SLOT_ADD_SELECTOR = (
        "[role='button']:has(i.google-symbols:text-is('add_2')), "
        "[role='button']:has(mat-icon:text-is('add_2'))"
    )
    # The exact ligature an icon-only slot-add candidate's inner_text reduces to.
    _CHARACTER_SLOT_ADD_LIGATURE = "add_2"

    # Current two-mode character editor (live 2026-07-26): Create Body reuses
    # the existing Slate prompt box instead of mounting a second one. The
    # language-independent ``accessibility_new`` icon activates body mode; the
    # generated-face reference chip (image + ``cancel`` icon) proves the mode
    # transition settled before the shared prompt box is safe to edit.
    #: Stays SCOPED on both hosts. The project-level "Characters" navigation control
    #: carries the same ``accessibility_new`` ligature, so a bare selector activates
    #: navigation instead of body mode.
    #:
    #: labs scopes it as the sibling of the portrait image button. The migrated
    #: editor gives us something better: each slot control is wrapped in its own
    #: ``<flow-slot-chip-button>`` custom element (recon 2026-09-06,
    #: ``scripts/dev/spike_migrated_character_body_controls.py``), which is a
    #: component boundary rather than a layout accident — the navigation control is
    #: not a slot chip, so it cannot match. The migrated host has **no** ``add_2``
    #: control at all; body mode is entered through this chip directly.
    #:
    #: The chip ships ``disabled`` until a portrait exists, which is why callers
    #: must wait for it to become enabled rather than clicking on sight.
    _CHARACTER_BODY_MODE_SELECTOR = (
        "button:has(img) + button:has(i.google-symbols:text-is('accessibility_new')), "
        "flow-slot-chip-button:has(mat-icon:text-is('accessibility_new')) button"
    )
    #: The settle signal for body mode: proof the generated face actually mounted as
    #: a reference, so the SHARED prompt box now belongs to body mode. Editing it
    #: earlier types the body prompt into the face composer (#395).
    #:
    #: labs mounts a dismissable card around a ``media.getMediaUrlRedirect`` image.
    #: The migrated host serves reference images from a different origin entirely —
    #: ``flow-content.google/image/<id>`` — and mounts a bare ``<img>`` with no card
    #: chrome. Measured 2026-09-06 (``spike_migrated_body_reference_chip.py``):
    #: absent before the Create body click, present after it, so it is a genuine
    #: transition signal and not something that is simply always on the page.
    _CHARACTER_BODY_REFERENCE_SELECTOR = (
        "button[data-card-open]:has(img[src*='media.getMediaUrlRedirect'])"
        ":has(i.google-symbols:text-is('cancel')), "
        "img[src*='flow-content.google/image/']"
    )

    # Character-editor model picker.  The editor shows a model chip ("🍌 Nano
    # Banana 2") with an ``arrow_drop_down`` ligature; clicking it opens a menu
    # whose options are the product names.  Product names ("Nano Banana 2" /
    # "Nano Banana Pro") are NOT localized, so text matching is acceptable here.
    #
    # ⚠️ NOT yet spiked from the live DOM — this is a reasonable best-effort
    # selector cascade, live-confirmed later.  A failed pick is NON-FATAL:
    # generation proceeds with Flow's default model.
    #: The ligature carrier differs by host — labs renders `<i class="google-symbols">`,
    #: flow.google.com renders `<mat-icon>` — so both are listed. A run that omitted the
    #: mat-icon variants logged `model-picker trigger not found` on the migrated host and
    #: generated on whatever tier the editor happened to open on (live 2026-09-06).
    _CHARACTER_MODEL_PICKER_TRIGGER_SELECTORS = (
        "button:has(i.google-symbols:text-is('arrow_drop_down'))",
        "button:has(mat-icon:text-is('arrow_drop_down'))",
        "[role='button']:has(i.google-symbols:text-is('arrow_drop_down'))",
        "[role='button']:has(mat-icon:text-is('arrow_drop_down'))",
    )

    #: Every character model is a "Nano Banana …" tier, so the model chip is the one
    #: `arrow_drop_down` control whose own text names one. The editor renders several
    #: such controls; picking `.first` blindly is how a picker ends up driving the
    #: wrong menu. Product names are not localized (see :data:`CHARACTER_MODELS`).
    _CHARACTER_MODEL_CHIP_HINT = "Nano Banana"

    #: How each CLI alias is recognised among the editor's menu entries. Reuses the
    #: migrated composer's matcher so both hosts obey the same #539 rule: match in
    #: Python, and REFUSE an ambiguous hit rather than resolving `.first`.
    #: "Nano Banana 2" is a prefix of "Nano Banana 2 Lite", so it must exclude it;
    #: "Nano Banana Pro" shares no prefix and needs no exclusion. Product names are
    #: not localized, which is why matching entries by display text is permitted
    #: here where the locale-invariance rule otherwise forbids it.
    _CHARACTER_MODEL_MATCHERS: ClassVar[dict[str, ModelMenuMatcher]] = {
        "nano2": ModelMenuMatcher("Nano Banana 2", excludes="Lite"),
        "nanopro": ModelMenuMatcher("Nano Banana Pro", excludes=None),
    }

    async def _find_character_model_chip(self, page: Any) -> tuple[Any | None, str]:
        """Return the model chip and the text it currently shows.

        Prefers a candidate whose text names a model tier over a bare positional
        `.first`, so a page carrying several `arrow_drop_down` controls cannot
        hand the picker somebody else's menu. Falls back to the first candidate
        when none names a tier — better to try than to skip the selection.
        """
        # Wait for SOMETHING to mount before enumerating. A bare count() races the
        # editor: the readiness gate only proves the prompt box exists, and the
        # model chip lands after it. Dropping this wait during a refactor turned a
        # working picker back into "model-picker trigger not found" (2026-09-06).
        for trig_sel in self._CHARACTER_MODEL_PICKER_TRIGGER_SELECTORS:
            try:
                await page.locator(trig_sel).first.wait_for(state="visible", timeout=4000)
                break
            except Exception:  # noqa: BLE001,PERF203 - try the next carrier
                continue

        fallback: Any | None = None
        fallback_text = ""
        for trig_sel in self._CHARACTER_MODEL_PICKER_TRIGGER_SELECTORS:
            locator = page.locator(trig_sel)
            for index in range(await locator.count()):
                candidate = locator.nth(index)
                text = (await candidate.text_content() or "").strip()
                if self._CHARACTER_MODEL_CHIP_HINT.casefold() in text.casefold():
                    return candidate, text
                if fallback is None:
                    fallback, fallback_text = candidate, text
        return fallback, fallback_text

    async def _select_character_model(
        self,
        page: Any,
        model_alias: str,
        out_dir: Any = None,
    ) -> None:
        """Apply the requested character model, or raise. Never silently proceed.

        ``model_alias`` is the friendly CLI alias (``"nano2"`` / ``"nanopro"``).

        **This is a hard gate, deliberately.** It used to be best-effort: every
        failure logged a warning and let the generation run on whatever tier the
        editor happened to show. For a CLI that is the worst outcome — the user
        gets a paid artifact from a model they did not ask for, and nothing in
        the output says so. Both halves of that were seen live on 2026-09-06:
        ``--model nano2`` generating on Pro because the picker assumed nano2 was
        the default, and a later run whose menu-item click timed out, leaving the
        tier unchanged while the generation proceeded.

        Aborting is **free**. Everything here happens before the prompt is
        submitted, so a raise costs no quota and no credits.

        The selection is verified by re-reading the chip afterwards rather than
        trusting the click, because the click is exactly what was observed to
        fail. One retry absorbs a menu that re-renders under us; anything else
        raises.

        Raises:
            :class:`~gflow_cli.errors.ConfigurationError`: the alias is unknown,
                or the menu does not offer exactly one entry matching it.
            :class:`~gflow_cli.errors.UiSelectorDriftError`: the picker or its
                menu could not be driven, or the tier did not apply.
        """
        matcher = self._CHARACTER_MODEL_MATCHERS.get(model_alias.lower())
        if matcher is None:
            raise ConfigurationError(
                detail=(
                    f"unknown character model {model_alias!r}; "
                    f"known aliases: {', '.join(sorted(self._CHARACTER_MODEL_MATCHERS))}"
                ),
                remediation_hint="Pass --model nano2 or --model nanopro.",
            )

        trigger, current = await self._find_character_model_chip(page)
        if trigger is None:
            await _capture_debug_screenshot(page, out_dir, "debug_character_model_picker.png")
            raise UiSelectorDriftError(
                detail=(
                    "character editor: the model picker (an arrow_drop_down control naming a "
                    f"model tier) was not found, so --model {model_alias} could not be applied. "
                    f"URL: {page.url}."
                ),
            )

        if matcher.matches(current):
            # Logged because the path is otherwise invisible: a run that
            # short-circuits emits no model event, and a field timeline cannot
            # tell "already on the tier you asked for" from "never looked".
            log.info(
                "ui_automation.character_model_already_selected",
                model=current,
                requested=model_alias,
            )
            return

        last_seen = current
        for attempt in (1, 2):
            await trigger.click(timeout=4000)
            # ``:visible`` is load-bearing. The editor keeps several menus in the
            # DOM at once (two `flow-add-menu`s plus the model `mat-menu`), so an
            # unscoped `[role='menuitem']` list mixes the open overlay's items
            # with hidden ones from the others. The text list and the clickable
            # list then disagree, and `nth(i)` — an index into the text list —
            # lands on a hidden node: `Locator.click: Timeout 4000ms exceeded`,
            # every time, while the same selector worked whenever the other menus
            # happened not to be mounted. Measured live 2026-09-06.
            items = page.locator(f"{MENU_ITEM}:visible")
            try:
                await items.first.wait_for(state="visible", timeout=5000)
            except Exception as e:
                await _capture_debug_screenshot(page, out_dir, "debug_character_model_picker.png")
                raise UiSelectorDriftError(
                    detail=(
                        "character editor: the model menu ([role='menuitem']) did not open, so "
                        f"--model {model_alias} could not be applied. URL: {page.url}."
                    ),
                ) from e

            # Matched in Python rather than through a `has_text` filter: an
            # *exclusion* is not expressible as has_text, the menu is read back for
            # the refusal diagnostic anyway, and more than one hit must REFUSE
            # instead of resolving `.first` (#539 — a `.first` on an ambiguous
            # selector picks a tier the user never asked for, and Flow bills it).
            offered = [t.strip() for t in await items.all_text_contents()]
            hits = [i for i, text in enumerate(offered) if matcher.matches(text)]
            if len(hits) != 1:
                await self._dismiss_character_model_menu(page)
                raise ConfigurationError(
                    detail=(
                        f"--model {model_alias} matched {len(hits)} entries in the character "
                        f"model menu; offered: {', '.join(offered) or '(none)'}"
                    ),
                    remediation_hint=(
                        "Pass a --model that names exactly one offered entry."
                        if hits
                        else "Pass --model with one of the offered names."
                    ),
                )

            try:
                await items.nth(hits[0]).click(timeout=4000)
            except Exception:  # noqa: BLE001 - a flaky click is what the retry is for
                log.warning(
                    "ui_automation.character_model_click_failed",
                    requested=model_alias,
                    attempt=attempt,
                )
                await self._dismiss_character_model_menu(page)
                continue
            await page.wait_for_timeout(400)

            # Verify, never assume: the click is precisely what was seen to fail.
            _, last_seen = await self._find_character_model_chip(page)
            if matcher.matches(last_seen):
                log.info(
                    "ui_automation.character_model_selected",
                    model=last_seen,
                    requested=model_alias,
                    attempt=attempt,
                )
                return
            log.warning(
                "ui_automation.character_model_not_applied",
                requested=model_alias,
                chip=last_seen,
                attempt=attempt,
            )

        await _capture_debug_screenshot(page, out_dir, "debug_character_model_picker.png")
        raise UiSelectorDriftError(
            detail=(
                f"character editor: --model {model_alias} did not apply — the model chip still "
                f"reads {last_seen!r} after two attempts. Refusing to generate on a tier you did "
                f"not ask for. URL: {page.url}."
            ),
        )

    async def _dismiss_character_model_menu(self, page: Any) -> None:
        """Close an open model menu; never fatal."""
        try:
            await page.keyboard.press("Escape")
            await page.wait_for_timeout(200)
        except Exception:  # noqa: BLE001 - dismissal is a courtesy
            log.debug("ui_automation.character_model_menu_dismiss_failed", exc_info=True)

    _CHARACTER_ROUTE_ATTEMPTS = 4
    _CHARACTER_ROUTE_BACKOFF_MS = 2_500

    async def _settle_on_character_route(
        self,
        page: Any,
        *,
        entity_id: str,
        url: str,
    ) -> None:
        """Ensure the browser actually CAME TO REST on ``/character/{entity_id}``.

        Flow bounces this route back to the project page when the entity is not
        yet queryable — a race gflow loses because it navigates immediately
        after ``flow.createEntity`` (live 2026-07-28).

        This must be checked explicitly because the project page **also** mounts
        a Slate prompt box, so the editor-ready wait below is satisfied on the
        WRONG surface. The generation then goes to the project composer, which
        sends no ``entityContext``, and Flow files the image as a plain project
        image with no ``parentEntityId`` — the #395 symptom. A redirect is
        therefore silent data loss, not a cosmetic detail.

        Re-navigates a few times to let the entity settle. If the route still
        will not stick, raise rather than type into the project composer.
        """
        for attempt in range(1, self._CHARACTER_ROUTE_ATTEMPTS + 1):
            if entity_id in str(page.url):
                if attempt > 1:
                    log.info(
                        "ui_automation.character_route_settled",
                        entity_id=entity_id,
                        attempt=attempt,
                    )
                return
            log.warning(
                "ui_automation.character_route_bounced",
                entity_id=entity_id,
                landed_on=str(page.url),
                attempt=attempt,
                note="Flow redirected away from the character editor; retrying",
            )
            if attempt == self._CHARACTER_ROUTE_ATTEMPTS:
                break
            await page.wait_for_timeout(self._CHARACTER_ROUTE_BACKOFF_MS)
            await page.goto(url, wait_until="domcontentloaded", timeout=45_000)
            await self._settle_if_redirecting(page)
            await self._dismiss_blocking_overlays(page, self._out_dir)

        shot = await _capture_debug_screenshot(
            page, self._out_dir, "debug_character_route_bounced.png"
        )
        msg = (
            f"Flow kept redirecting the character editor for entity {entity_id!r} "
            f"back to {page.url!r} after {self._CHARACTER_ROUTE_ATTEMPTS} attempts. "
            "Generating here would submit through the PROJECT composer and Flow "
            "would file the image as a plain project image instead of binding it "
            f"to the character.{screenshot_clause(shot)}"
        )
        raise FlowAppError(detail=msg)

    async def _enter_character_editor(
        self,
        page: Any,
        *,
        project_id: str,
        entity_id: str,
        locale: str | None,
    ) -> None:
        """Navigate to the Flow character editor for an existing entity.

        Does NOT create a new project — navigates directly to the existing
        project's character editor URL via ``page.goto``.

        Readiness gate: waits for the prompt textbox
        (``div[role=textbox][data-slate-editor='true']``) to become visible,
        confirming the Slate editor has mounted.  Overlays are dismissed
        after navigation so they don't block subsequent interactions.
        """
        from gflow_cli.api import routes

        url = routes.character_editor_url(locale, project_id, entity_id)
        log.info(
            "ui_automation.entering_character_editor",
            url=url,
            project_id=project_id,
            entity_id=entity_id,
        )
        await page.goto(url, wait_until="domcontentloaded", timeout=45_000)
        # #580: settle BEFORE any DOM work — #395's "character-route bounce" is
        # this exact race. `_settle_on_character_route` below only checks that
        # `entity_id` is still in the URL, which a locale-only redirect PRESERVES,
        # so it returns instantly and cannot substitute for this wait.
        await self._settle_if_redirecting(page)
        await self._dismiss_blocking_overlays(page, self._out_dir)
        await self._settle_on_character_route(page, entity_id=entity_id, url=url)

        # NO migrated-host guard here, deliberately. One stood here and was
        # wrong: flow.google.com renders the character editor in full — name,
        # voice, personality, Upload / Add from project, Create portrait /
        # Create body — against the SAME labs tRPC and aisandbox backend
        # (recon 2026-09-06, scripts/dev/spike_migrated_vs_labs_provenance.py:
        # the migrated page itself calls flow.projectInitialData and
        # v1:checkAppAvailability). What differed was the view layer, React +
        # Slate vs Angular + ProseMirror, so the readiness selector missed and
        # a present feature was read as an absent one. The guard then turned
        # that misreading into a confident, non-retryable "this host will never
        # do it". Do not reinstate it without live evidence that the editor is
        # actually gone.

        # Wait for the Slate editor to mount — the prompt textbox is the
        # reliable "editor ready" anchor for the character editor surface.
        try:
            await page.locator(self._CHARACTER_EDITOR_READY_SELECTOR).first.wait_for(
                state="visible",
                timeout=20_000,
            )
        except Exception as exc:
            shot = await _capture_debug_screenshot(
                page,
                self._out_dir,
                "debug_character_editor_not_ready.png",
            )
            # Flow's web app crashes on this route often enough to be the
            # DOMINANT cause of a missing textbox (live 2026-07-27: the
            # incident bundle's ui.json reported title category
            # `flow_app_crash` with zero ligatures — Flow's React error
            # boundary, not the editor). Reuse the mode-switch path's
            # classifier so the user gets the typed, retryable FlowAppError
            # (exit 31) that says "Flow broke, retry" instead of a bare
            # RuntimeError blaming a selector that was never on the page.
            if await self._is_flow_app_crash(page):
                raise FlowAppError(
                    detail=(
                        "Flow's web app crashed (client-side exception) instead of "
                        f"rendering the character editor at {page.url}, so there is "
                        f"no prompt box to drive.{screenshot_clause(shot)}"
                    )
                ) from exc
            msg = (
                f"Character editor not ready: prompt textbox not visible "
                f"within 20 s. URL: {page.url}.{screenshot_clause(shot)}"
            )
            raise RuntimeError(msg) from exc

        log.info("ui_automation.character_editor_ready", url=page.url)

    @staticmethod
    def _workflows_from_responses(
        responses: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Extract workflow metadata from captured batchGenerateImages responses.

        Returns a flat list of workflow dicts, each containing at minimum:
        ``name``, ``metadata`` (with ``primaryMediaId``), ``projectId``, and
        ``parentEntityId``.  The ``parentEntityId`` field binds the generation
        result to the character entity.

        Only workflow entries present in 200-status responses are returned;
        error responses are silently skipped (``_images_from_responses`` already
        raises on 401/403 before this is called).
        """
        workflows: list[dict[str, Any]] = []
        for response in responses:
            if response.get("status") != 200:
                continue
            body: dict[str, Any] = cast(_JsonObj, response.get("body") or {})
            raw_workflows = body.get("workflows", [])
            if not isinstance(raw_workflows, list):
                continue
            for wf_raw in cast(_AnyList, raw_workflows):
                if not isinstance(wf_raw, dict):
                    continue
                wf: dict[str, Any] = cast(_JsonObj, wf_raw)
                # Only surface workflows that carry the character-binding field.
                if "parentEntityId" not in wf:
                    log.debug(
                        "ui_automation.workflow_missing_parent_entity_id",
                        workflow_name=wf.get("name"),
                    )
                workflows.append(wf)
        return workflows

    async def generate_character_images(
        self,
        *,
        project_id: str,
        entity_id: str,
        request: CharacterImageRequest,
        image_reference_index: int,
        locale: str | None,
        format_prompt: bool = False,
    ) -> tuple[list[GeneratedImage], list[dict[str, Any]]]:
        """Navigate to the character editor and generate images via passive capture.

        Reuses the same generate lock, listener, and parse helpers as the
        image-generation path — the difference is that we navigate to an
        EXISTING project's character editor (not a new project), and we
        return workflow metadata alongside the images so the caller can bind
        results to the character entity via ``parentEntityId``.

        ``image_reference_index``:
          - 0 → face slot (no body-mode interaction needed; the slot is
            already active in the character editor).
          - >= 1 → body / accessory slot; activate body mode and wait for its
            structural settle signal before submitting the prompt.

        Returns ``(images, workflows)`` where each ``workflows`` entry carries
        at minimum ``name``, ``metadata.primaryMediaId``, ``projectId``, and
        ``parentEntityId``.
        """
        if not self._setup_done or self._page is None:
            msg = "UiAutomationTransport.setup() must be called before generate_character_images()"
            raise RuntimeError(msg)

        async with self._generate_lock:
            return await self._generate_character_images_locked(
                project_id=project_id,
                entity_id=entity_id,
                request=request,
                image_reference_index=image_reference_index,
                locale=locale,
                format_prompt=format_prompt,
            )

    async def _generate_character_images_locked(
        self,
        *,
        project_id: str,
        entity_id: str,
        request: CharacterImageRequest,
        image_reference_index: int,
        locale: str | None,
        format_prompt: bool = False,
    ) -> tuple[list[GeneratedImage], list[dict[str, Any]]]:
        """Serialized body of generate_character_images — called under _generate_lock."""
        page: Any = self._page  # type: ignore[assignment]  # guard in caller
        out_dir = self._out_dir

        await self._enter_character_editor(
            page,
            project_id=project_id,
            entity_id=entity_id,
            locale=locale,
        )
        await self._dismiss_blocking_overlays(page, out_dir)

        # Characters have NO aspect-ratio control and NO per-generation settings
        # panel (the live editor renders neither — the old
        # _configure_generation_settings call only ever logged
        # ``gen_settings_panel_not_found`` and skipped).  Model selection uses
        # the editor's OWN model dropdown instead.  ``request.model`` is the
        # friendly CLI alias ("nano2" / "nanopro").  Best-effort, non-fatal:
        # a failed pick proceeds with Flow's default model.  Character
        # generation is always exactly one image per slot.
        await self._select_character_model(page, request.model, out_dir)

        # Face (index 0) needs no mode interaction; body/accessories do.
        # Activating body mode auto-attaches the generated face as a reference.
        # Current Flow reuses the Slate box; legacy cohorts mount another one.
        # The body path replaces the settled composer with gflow's own prompt.
        is_body_slot = image_reference_index >= 1
        boxes_before = 0
        shared_body_box = False
        if is_body_slot:
            # Snapshot the count for legacy cohorts before activating body
            # mode. Current Flow proves the shared box is safe by mounting the
            # generated-face reference; legacy Flow proves it by count rise.
            boxes_before = await self._count_character_prompt_boxes(page)
            shared_body_box = await self._click_character_slot_add(page, out_dir)

        # Attach listener BEFORE submit to eliminate the race condition.
        captured, detach = self._attach_batch_response_listener(page, project_id=project_id)
        submit_time = time.monotonic()
        responses: list[dict[str, Any]] = []
        try:
            if is_body_slot:
                await self._submit_body_prompt(
                    page,
                    request.prompt,
                    boxes_before=boxes_before,
                    shared_body_box=shared_body_box,
                    out_dir=out_dir,
                    format_prompt=format_prompt,
                )
            else:
                await self._send_prompt(page, request.prompt, out_dir, format_prompt=format_prompt)
            responses = await self._await_captured(
                captured,
                expected_count=1,
                submit_time=submit_time,
            )
        finally:
            detach()

        images, first_error_status, first_error_route, first_error_body = _images_from_responses(
            responses
        )

        if first_error_status is not None and not images:
            # #528: a 400 here is a content-policy rejection, not a wire problem.
            raise generation_error(
                status=first_error_status,
                route=first_error_route,
                body=first_error_body,
            )

        if not images:
            from gflow_cli.errors import ContentPolicyError

            raise ContentPolicyError(
                detail="batchGenerateImages returned 200 but no parseable media items",
                route=first_error_route or "",
            )

        workflows = self._workflows_from_responses(responses)
        return images, workflows

    async def _click_character_slot_add(
        self,
        page: Any,
        out_dir: Any = None,
    ) -> bool:
        """Activate body mode; return whether it uses the settled shared box.

        Current Flow (live 2026-07-26) exposes a Create Body button carrying
        the locale-independent ``accessibility_new`` icon. Clicking it reuses
        the existing Slate box. The generated-face reference chip must become
        visible before this method returns ``True``; that structural signal
        proves the shared box now belongs to body mode.

        Legacy DOM evidence (2026-06-02 spike) showed the character editor renders
        two ``add_2`` ligatures that are STRUCTURALLY distinct (see the
        ``_CHARACTER_SLOT_ADD_SELECTOR`` constant for the full DOM): the slot-add
        target is a ``[role=button]`` whose accessible content is icon-ONLY,
        while the decoy is a ``<button>`` that also carries a hidden text-label
        ``<span>``.  The previous ``.nth(1)`` heuristic was wrong — it indexed
        into a ``<button>``-only locator that never even matched the slot-add
        div.

        Selection logic (language-agnostic):

        1. Locate every ``[role=button]`` that hosts an ``add_2`` icon.
        2. Keep only the icon-ONLY candidates — those whose stripped
           ``inner_text`` is exactly the ``add_2`` ligature.  The decoy's hidden
           label lengthens its inner_text, excluding it.
        3. If exactly one icon-only candidate remains, click it.  If several
           remain, prefer the first (the slot-add renders adjacent to the
           character image slots, ahead of any other icon-only ``add_2``).

        The localised ``aria-label`` is intentionally NOT part of the predicate
        ([[flow-locale-leak-icon-ligatures]]); the icon-only test is the anchor.

        The legacy path returns ``False`` because it mounts a second prompt
        box. Non-fatal here: a miss is logged at WARNING.  Enforcement lives in
        ``_locate_body_prompt_box`` — if the body composer's own prompt box
        never mounts, the body step ABORTS instead of typing into whichever
        slot is currently active (which would overwrite the portrait prompt).
        """
        body_mode = page.locator(self._CHARACTER_BODY_MODE_SELECTOR).first
        try:
            await body_mode.wait_for(state="visible", timeout=5_000)
        except Exception as exc:
            body_mode_error = str(exc)[:120]
        else:
            references_before = int(
                await page.locator(self._CHARACTER_BODY_REFERENCE_SELECTOR).count()
            )
            await body_mode.click()
            try:
                face_references = page.locator(self._CHARACTER_BODY_REFERENCE_SELECTOR)
                await face_references.first.wait_for(state="visible", timeout=5_000)
                references_now = int(await face_references.count())
                if references_now <= references_before:
                    raise RuntimeError(
                        "generated-face reference did not mount after Create Body click"
                    )
            except Exception as exc:
                shot = await _capture_debug_screenshot(
                    page, out_dir, "debug_character_body_mode_unsettled.png"
                )
                msg = (
                    "Create Body was selected, but its generated-face reference did not mount. "
                    "Aborting before prompt editing; the legacy control will not be tried after "
                    f"a partial mode transition. URL: {page.url}.{screenshot_clause(shot)}"
                )
                raise RuntimeError(msg) from exc
            await page.wait_for_timeout(400)
            log.info(
                "ui_automation.character_body_mode_activated",
                selector=self._CHARACTER_BODY_MODE_SELECTOR,
                settle_signal=self._CHARACTER_BODY_REFERENCE_SELECTOR,
                shared_body_box=True,
                references_before=references_before,
                references_now=references_now,
            )
            return True

        try:
            loc = page.locator(self._CHARACTER_SLOT_ADD_SELECTOR)
            await loc.first.wait_for(state="visible", timeout=5_000)
            total = await loc.count()
            chosen = None
            chosen_index = -1
            for i in range(total):
                cand = loc.nth(i)
                try:
                    raw = await cand.inner_text()
                except Exception:
                    continue
                # Icon-only ⇔ the accessible text reduces to just the ligature.
                # The decoy carries a hidden label span → longer inner_text.
                if raw.strip() == self._CHARACTER_SLOT_ADD_LIGATURE:
                    chosen = cand
                    chosen_index = i
                    break
            if chosen is None:
                raise RuntimeError(f"no icon-only add_2 [role=button] among {total} candidate(s)")
            await chosen.click()
            await page.wait_for_timeout(400)
            log.info(
                "ui_automation.character_slot_add_clicked",
                image_reference_index=1,
                selector=self._CHARACTER_SLOT_ADD_SELECTOR,
                candidates=total,
                chosen_index=chosen_index,
            )
            return False
        except Exception as exc:
            shot = await _capture_debug_screenshot(page, out_dir, "debug_character_slot_add.png")
            log.warning(
                "ui_automation.character_slot_add_failed",
                error=str(exc)[:120],
                body_mode_error=body_mode_error,
                screenshot=str(shot),
                note=(
                    "slot-add button not found; the body step will abort "
                    "unless the body prompt box is already mounted"
                ),
            )
            return False

    # ------------------------------------------------------------------
    # Protocol — refresh_auth (unit 3.10) + teardown (unit 3.11)
    # ------------------------------------------------------------------

    async def refresh_auth(self) -> None:
        """No-op for the UI strategy.

        Flow's own JavaScript re-mints reCAPTCHA tokens and refreshes
        auth state inside the Page on every prompt submission. There is
        no separate token cache to refresh from this strategy's side.
        Kept on the Protocol surface for consistency with the HTTP
        strategies (S1/S2/S3) where refresh_auth has real work to do.
        """
        await asyncio.sleep(0)  # yield to event loop — Protocol-required async signature
        log.debug("ui_automation.refresh_auth_noop")

    async def teardown(self) -> None:
        """Close the Playwright context if this strategy owns it.

        Idempotent — safe to call multiple times. When ``_owns_playwright``
        is False (shared-page setup) the caller retains lifecycle
        ownership; this method releases nothing and just resets state.
        """
        if not self._setup_done:
            return
        from gflow_cli.api._engine import (  # noqa: PLC0415
            CONTEXT_TEARDOWN_TIMEOUT_S,
            DRIVER_STOP_TIMEOUT_S,
            close_context_bounded,
            run_teardown_step,
        )

        # Cancellation-complete teardown (D4): each step is bounded + shielded so
        # a CancelledError landing mid-close cannot skip the driver exit or the
        # lease release in `finally`; the original cancellation re-raises last.
        # Teardown order: (4) close context -> exit driver; (6) release lease.
        cancelled: BaseException | None = None
        try:
            if self._owns_playwright and self._pw_cm is not None:
                if self._ctx is not None:
                    # Bounded close + force-close fallback (issue #293) — same
                    # helper as FlowApiClient's teardown; this standalone path
                    # had the identical unbounded-close-and-swallow gap.
                    cancelled = (
                        await run_teardown_step(
                            close_context_bounded(self._ctx, owner="ui_automation"),
                            timeout=CONTEXT_TEARDOWN_TIMEOUT_S,
                            owner="ui_automation",
                            step="context_close",
                        )
                        or cancelled
                    )
                cancelled = (
                    await run_teardown_step(
                        self._pw_cm.__aexit__(None, None, None),
                        timeout=DRIVER_STOP_TIMEOUT_S,
                        owner="ui_automation",
                        step="driver_exit",
                    )
                    or cancelled
                )
        finally:
            # Release the profile lease last — after the context is closed and
            # the driver stopped (D3). No-op on the shared-page path (lease is
            # None). Field resets survive even a cancelled teardown.
            if self._lease is not None:
                self._lease.release()
                self._lease = None
            self._pw_cm = None
            self._ctx = None
            self._page = None
            self._setup_done = False
            self._owns_playwright = False
        if cancelled is not None:
            raise cancelled
