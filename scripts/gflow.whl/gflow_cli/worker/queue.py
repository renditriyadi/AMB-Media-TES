from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any, cast

from gflow_cli.errors import DataIntegrityError, QueueSchemaError, is_retryable
from gflow_cli.worker import codec

if TYPE_CHECKING:
    from collections.abc import Sequence

    from gflow_cli.data.store import DataStore

# Version of the persisted checkpoint document (its own small versioned dict,
# deliberately NOT merged with the api.dto GenerationCheckpoint DTO).
CHECKPOINT_SCHEMA_VERSION = 1

# Columns selected to build a QueueTask — one list, one row->task mapping.
_TASK_COLUMNS = (
    "task_id, profile_name, task_type, payload_json, status, flow_media_id, "
    "error_json, claimant, claimed_at, checkpoint_json, created_at, updated_at"
)


def _utc_now() -> str:
    return datetime.now(UTC).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def make_checkpoint_document(
    *,
    claimant: str,
    phase: str,
    may_have_spent: bool,
    project_id: str | None,
    operation_id: str | None = None,
    media_ids: Sequence[str] = (),
    workflow_ids: Sequence[str] = (),
) -> dict[str, Any]:
    """Build a versioned, redacted checkpoint document for a queue task.

    Carries ONLY claimant identity, execution phase, a spend flag, the
    credit-free-recovery ``project_id`` (design-spec Appendix A / C1 spike),
    and observed Flow handles. It MUST NEVER carry prompt text, credentials,
    cookies, or signed URLs — the shape here is the allow-list.
    """
    return {
        "schema_version": CHECKPOINT_SCHEMA_VERSION,
        "claimant": claimant,
        "phase": phase,
        "may_have_spent": may_have_spent,
        "project_id": project_id,
        "operation_id": operation_id,
        "media_ids": list(media_ids),
        "workflow_ids": list(workflow_ids),
    }


@dataclass(frozen=True)
class QueueTask:
    task_id: str
    profile_name: str
    task_type: str
    payload: dict[str, Any]
    status: str
    flow_media_id: str | None = None
    error: dict[str, Any] | None = None
    claimant: str | None = None
    claimed_at: str | None = None
    checkpoint: dict[str, Any] | None = None
    created_at: str | None = None
    updated_at: str | None = None
    # Transient (never persisted): the validated request from the claim-time
    # decode, threaded to the executor so it does not re-derive the payload
    # mapping post-claim. Populated ONLY by the claim path; None everywhere else.
    decoded: codec.DecodedPayload | None = None


def _row_to_task(row: sqlite3.Row, decoded: codec.DecodedPayload | None = None) -> QueueTask:
    return QueueTask(
        task_id=row["task_id"],
        profile_name=row["profile_name"],
        task_type=row["task_type"],
        payload=json.loads(row["payload_json"]),
        status=row["status"],
        flow_media_id=row["flow_media_id"],
        error=json.loads(row["error_json"]) if row["error_json"] else None,
        claimant=row["claimant"],
        claimed_at=row["claimed_at"],
        checkpoint=json.loads(row["checkpoint_json"]) if row["checkpoint_json"] else None,
        created_at=row["created_at"],
        updated_at=row["updated_at"],
        decoded=decoded,
    )


class QueueRepository:
    def __init__(self, store: DataStore) -> None:
        self._store = store

    @property
    def store(self) -> DataStore:
        return self._store

    def enqueue_task(
        self,
        task_id: str,
        profile_name: str,
        task_type: str,
        payload: dict[str, Any],
    ) -> QueueTask:
        now = _utc_now()
        payload_str = json.dumps(payload)
        try:
            with self._store.transaction(immediate=True):
                self._store.conn.execute(
                    """
                    INSERT INTO generation_queue(
                        task_id, profile_name, task_type,
                        payload_json, status, created_at, updated_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (task_id, profile_name, task_type, payload_str, "pending", now, now),
                )
        except sqlite3.IntegrityError as exc:
            raise DataIntegrityError(detail=str(exc), route="queue.enqueue_task") from exc

        return QueueTask(
            task_id=task_id,
            profile_name=profile_name,
            task_type=task_type,
            payload=payload,
            status="pending",
            created_at=now,
            updated_at=now,
        )

    def get_task(self, task_id: str) -> QueueTask | None:
        row = self._store.conn.execute(
            f"SELECT {_TASK_COLUMNS} FROM generation_queue WHERE task_id = ?",
            (task_id,),
        ).fetchone()
        return _row_to_task(row) if row is not None else None

    def get_processing_tasks(self, profile_name: str) -> list[QueueTask]:
        """All currently-``processing`` rows for a profile, oldest first.

        Startup crash recovery (:func:`recover_processing`) reads each row's
        checkpoint to classify it, rather than blanket-failing them all.
        """
        rows = self._store.conn.execute(
            f"""
            SELECT {_TASK_COLUMNS} FROM generation_queue
            WHERE profile_name = ? AND status = 'processing'
            ORDER BY created_at ASC
            """,
            (profile_name,),
        ).fetchall()
        return [_row_to_task(row) for row in rows]

    def claim_next_pending(self, profile_name: str, claimant: str) -> QueueTask | None:
        """Atomically claim the oldest pending task for a profile.

        Holds a single ``BEGIN IMMEDIATE`` write transaction across: select
        the oldest pending row, decode+validate its payload (C2 codec), fail
        an invalid row WITHOUT opening a browser, or conditionally transition
        exactly that row ``pending`` -> ``processing`` with claimant metadata.
        Returns the claimed task, or ``None`` when the queue is empty or the
        row was rejected as invalid.
        """
        with self._store.transaction(immediate=True):
            row = self._store.conn.execute(
                f"""
                SELECT {_TASK_COLUMNS} FROM generation_queue
                WHERE profile_name = ? AND status = 'pending'
                ORDER BY created_at ASC
                LIMIT 1
                """,
                (profile_name,),
            ).fetchone()
            if row is None:
                return None
            return self._claim_row(row, claimant)

    def claim_task(self, task_id: str, claimant: str) -> QueueTask | None:
        """Atomically claim one specific task by id — same transaction and
        decode-at-claim semantics as :meth:`claim_next_pending`. Returns
        ``None`` if the task is missing, not pending, or invalid."""
        with self._store.transaction(immediate=True):
            row = self._store.conn.execute(
                f"SELECT {_TASK_COLUMNS} FROM generation_queue "
                "WHERE task_id = ? AND status = 'pending'",
                (task_id,),
            ).fetchone()
            if row is None:
                return None
            return self._claim_row(row, claimant)

    def _claim_row(self, row: sqlite3.Row, claimant: str) -> QueueTask | None:
        """Decode-then-transition a selected pending row. Called INSIDE an open
        ``BEGIN IMMEDIATE`` transaction. An invalid payload is marked failed
        (no browser launch) and ``None`` returned; a valid payload is moved to
        ``processing``. Never raises for a bad payload — that would roll back
        the failure write."""
        task_id = row["task_id"]
        now = _utc_now()
        try:
            decoded = codec.decode_payload(row["task_type"], json.loads(row["payload_json"]))
        except QueueSchemaError as exc:
            error_payload = dict(exc.to_problem_details())
            error_payload.setdefault("status", 400)
            # §6.5: same shared retry classification as CLI --json / MCP.
            error_payload["retryable"] = is_retryable(exc)
            self._store.conn.execute(
                "UPDATE generation_queue "
                "SET status = 'failed', error_json = ?, updated_at = ? WHERE task_id = ?",
                (json.dumps(error_payload), now, task_id),
            )
            return None

        # Conditional transition — the WHERE status='pending' guard is
        # belt-and-suspenders under the IMMEDIATE write lock (a second claimant
        # blocks on the lock, then sees 'processing' and selects nothing).
        self._store.conn.execute(
            "UPDATE generation_queue "
            "SET status = 'processing', claimant = ?, claimed_at = ?, updated_at = ? "
            "WHERE task_id = ? AND status = 'pending'",
            (claimant, now, now, task_id),
        )
        claimed = self._store.conn.execute(
            f"SELECT {_TASK_COLUMNS} FROM generation_queue WHERE task_id = ?",
            (task_id,),
        ).fetchone()
        return _row_to_task(claimed, decoded=decoded)

    def update_checkpoint(
        self,
        task_id: str,
        *,
        claimant: str,
        phase: str,
        may_have_spent: bool,
        project_id: str | None = None,
        operation_id: str | None = None,
        media_ids: Sequence[str] = (),
        workflow_ids: Sequence[str] = (),
    ) -> None:
        """Build (via :func:`make_checkpoint_document` — the redaction allow-list)
        and persist a checkpoint. This is the writer callers SHOULD use: routing
        every checkpoint write through the builder is the privacy guarantee (the
        low-level :meth:`write_checkpoint` accepts any dict and stays only for the
        C3 roundtrip test)."""
        self.write_checkpoint(
            task_id,
            make_checkpoint_document(
                claimant=claimant,
                phase=phase,
                may_have_spent=may_have_spent,
                project_id=project_id,
                operation_id=operation_id,
                media_ids=media_ids,
                workflow_ids=workflow_ids,
            ),
        )

    def write_checkpoint(self, task_id: str, checkpoint: dict[str, Any]) -> None:
        """Persist a versioned checkpoint document (see
        :func:`make_checkpoint_document`) onto a task row."""
        now = _utc_now()
        with self._store.transaction(immediate=True):
            self._store.conn.execute(
                "UPDATE generation_queue SET checkpoint_json = ?, updated_at = ? WHERE task_id = ?",
                (json.dumps(checkpoint), now, task_id),
            )

    def read_checkpoint(self, task_id: str) -> dict[str, Any] | None:
        """Read a task's checkpoint document, or ``None`` if unset/missing."""
        row = self._store.conn.execute(
            "SELECT checkpoint_json FROM generation_queue WHERE task_id = ?",
            (task_id,),
        ).fetchone()
        if row is None or row["checkpoint_json"] is None:
            return None
        return cast("dict[str, Any]", json.loads(row["checkpoint_json"]))

    def update_task_status(
        self,
        task_id: str,
        status: str,
        flow_media_id: str | None = None,
        error: dict[str, Any] | None = None,
    ) -> None:
        now = _utc_now()
        error_str = json.dumps(error) if error is not None else None
        try:
            with self._store.transaction(immediate=True):
                self._store.conn.execute(
                    """
                    UPDATE generation_queue
                    SET status = ?,
                        flow_media_id = COALESCE(?, flow_media_id),
                        error_json = COALESCE(?, error_json),
                        updated_at = ?
                    WHERE task_id = ?
                    """,
                    (status, flow_media_id, error_str, now, task_id),
                )
        except sqlite3.IntegrityError as exc:
            raise DataIntegrityError(detail=str(exc), route="queue.update_task_status") from exc


def classify_interrupted(checkpoint: dict[str, Any] | None) -> str:
    """Truthful terminal status for a task interrupted (cancelled or crashed)
    while ``processing``, keyed on how far its checkpoint got.

    * pre-submit — no checkpoint, or ``phase`` still ``claimed`` → ``failed``
      (the credit-spending gesture never fired; nothing was spent, safe to retry).
    * post-submit — ``phase`` is ``submit_attempted`` or ``remote_started`` →
      ``indeterminate`` (a credit MAY have been spent and the outcome is unknown;
      it must NEVER be silently reported as ``failed`` and NEVER auto-resubmitted).
    """
    phase = (checkpoint or {}).get("phase")
    if phase in ("submit_attempted", "remote_started"):
        return "indeterminate"
    return "failed"


def _recovery_error(status: str, reason: str) -> dict[str, Any]:
    if status == "indeterminate":
        return {
            "type": "https://gflow-cli.dev/errors/indeterminate-outcome",
            "title": "Indeterminate Generation Outcome",
            "status": 202,
            "detail": (
                f"Task interrupted ({reason}) after submit was attempted; a credit "
                "may have been spent and the outcome is unknown. NOT retried automatically."
            ),
        }
    return {
        "type": "https://gflow-cli.dev/errors/daemon-recovery",
        "title": "Interrupted Before Submit",
        "status": 500,
        "detail": f"Task interrupted ({reason}) before any submit; nothing spent, safe to retry.",
    }


def mark_interrupted(
    repo: QueueRepository,
    task_id: str,
    checkpoint: dict[str, Any] | None,
    reason: str,
) -> str:
    """Persist the truthful terminal state for one interrupted task and return it.

    Shared by the daemon's ``CancelledError`` handler and startup
    :func:`recover_processing` so the phase→status classification lives in exactly
    one place.
    """
    status = classify_interrupted(checkpoint)
    repo.update_task_status(task_id, status=status, error=_recovery_error(status, reason))
    return status


def recover_processing(
    repo: QueueRepository,
    profile_name: str,
    client: object | None = None,
) -> dict[str, int]:
    """Startup crash recovery: move every ``processing`` row for the profile to a
    truthful terminal state based on its checkpoint, instead of blanket-failing.

    NEVER calls generation — a task whose submit may have spent a credit is marked
    ``indeterminate`` (with its handle preserved in the checkpoint), never retried.

    ``client`` is the handle-only reconcile hook. Per the C1 spike (design-spec
    Appendix A) an offline handle→status readback is impossible — the Flow status
    endpoint 401s a bare ``page.request``, so only a live SPA re-poll can turn a
    handle into status. Until F1 confirms credit-free project-page re-entry, a
    ``remote_started`` task is left ``indeterminate`` and ``client`` is unused;
    it is here so the no-resubmit contract stays testable (``submit_count == 0``)
    and so D3/D4's live reconciler has its seam.
    """
    _ = client  # ponytail: reconcile hook, unused until F1 live-page readback lands
    counts = {"failed": 0, "indeterminate": 0}
    for task in repo.get_processing_tasks(profile_name):
        status = mark_interrupted(repo, task.task_id, task.checkpoint, "daemon restart")
        counts[status] += 1
    return counts
